# WordPress MySQL database migration
#
# Generated: Thursday 10. May 2018 18:45 UTC
# Hostname: localhost
# Database: `portshowlio18`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-04-05 02:11:06', '2018-04-05 02:11:06', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=605 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://2018.portshowl.io', 'yes'),
(2, 'home', 'http://2018.portshowl.io', 'yes'),
(3, 'blogname', 'Portshwolio18 test', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'atiagina@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:111:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"student/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"student/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"student/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"student/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"student/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"student/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"student/([^/]+)/embed/?$";s:40:"index.php?student=$matches[1]&embed=true";s:28:"student/([^/]+)/trackback/?$";s:34:"index.php?student=$matches[1]&tb=1";s:36:"student/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?student=$matches[1]&paged=$matches[2]";s:43:"student/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?student=$matches[1]&cpage=$matches[2]";s:32:"student/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?student=$matches[1]&page=$matches[2]";s:24:"student/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"student/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"student/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"student/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"student/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"student/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=14&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:10:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:51:"codepress-admin-columns/codepress-admin-columns.php";i:2;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:3;s:57:"scalable-vector-graphics-svg/scalable-vector-graphics.php";i:4;s:37:"user-role-editor/user-role-editor.php";i:5;s:55:"view-own-posts-media-only/view-own-posts-media-only.php";i:6;s:24:"wordpress-seo/wp-seo.php";i:7;s:63:"wp-migrate-db-pro-media-files/wp-migrate-db-pro-media-files.php";i:8;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";i:9;s:21:"wppusher/wppusher.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:5:{i:0;s:80:"/nas/content/live/portshowlio18/wp-content/themes/portshowlio18-splash/style.css";i:1;s:84:"/nas/content/live/portshowlio18/wp-content/themes/portshowlio18-splash/css/style.css";i:3;s:81:"/nas/content/live/portshowlio18/wp-content/themes/portshowlio18-splash/styles.css";i:4;s:73:"/nas/content/live/portshowlio18/wp-content/themes/portshowlio17/style.css";i:5;s:77:"/nas/content/live/portshowlio18/wp-content/themes/portshowlio17/css/style.css";}', 'no'),
(40, 'template', 'portshowlio18', 'yes'),
(41, 'stylesheet', 'portshowlio18', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '14', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:70:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"manage_admin_columns";b:1;s:14:"ure_edit_roles";b:1;s:16:"ure_create_roles";b:1;s:16:"ure_delete_roles";b:1;s:23:"ure_create_capabilities";b:1;s:23:"ure_delete_capabilities";b:1;s:18:"ure_manage_options";b:1;s:15:"ure_reset_roles";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'cron', 'a:4:{i:1526004666;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1526004683;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1526061992;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(110, 'theme_mods_twentyseventeen', 'a:3:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1524764890;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}s:18:"nav_menu_locations";a:0:{}}', 'yes'),
(125, 'can_compress_scripts', '1', 'no'),
(138, 'theme_mods_portshowlio17-master', 'a:1:{s:18:"custom_css_post_id";i:-1;}', 'yes'),
(142, 'theme_mods_portshowlio17', 'a:3:{s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:0:{}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1524764294;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(144, 'theme_mods_portshowlio-starter', 'a:3:{s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:0:{}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1524764884;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(163, 'current_theme', 'portshowlio18-new', 'yes'),
(164, 'theme_switched', '', 'yes'),
(188, 'recently_activated', 'a:0:{}', 'yes'),
(189, 'acf_version', '5.3.8.1', 'yes'),
(192, 'cptui_new_install', 'false', 'yes'),
(195, 'cpac-install-timestamp', '1522956050', 'no'),
(196, 'user_role_editor', 'a:1:{s:11:"ure_version";s:4:"4.33";}', 'yes'),
(197, 'wp_backup_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"manage_admin_columns";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'no'),
(198, 'ure_tasks_queue', 'a:0:{}', 'yes'),
(199, 'wppusher_token', 'a9b98ae25fc8e004b3a6220d24c082dc8951ac8e5c4a0e038edb1572c116277f', 'yes'),
(200, 'gl_base_url', 'https://gitlab.com', 'yes'),
(205, 'wpseo', 'a:24:{s:14:"blocking_files";a:0:{}s:15:"ms_defaults_set";b:0;s:7:"version";s:3:"4.8";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:19:"onpage_indexability";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";b:0;s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:20:"enable_setting_pages";b:0;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";i:1522956612;}', 'yes'),
(206, 'wpseo_permalinks', 'a:9:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes'),
(207, 'wpseo_titles', 'a:54:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:5:"noodp";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes'),
(208, 'wpseo_social', 'a:20:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"a61a3a23c2fd7ce61d68bca6a29f2cbb";s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(209, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes'),
(210, 'wpseo_internallinks', 'a:10:{s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:0;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:23:"post_types-post-maintax";i:0;}', 'yes'),
(211, 'wpseo_xml', 'a:16:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:14:"excluded-posts";s:0:"";s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;}', 'yes'),
(212, 'wpseo_flush_rewrite', '1', 'yes'),
(217, 'theme_mods_portshowlio17-splash-master', 'a:3:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1523503667;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}s:18:"nav_menu_locations";a:0:{}}', 'yes'),
(219, 'theme_switched_via_customizer', '', 'yes'),
(220, 'customize_stashed_theme_mods', 'a:0:{}', 'no'),
(223, 'theme_mods_portshowlio16-splash-master', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1522963165;s:4:"data";a:1:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(235, 'theme_mods_portshowlio18-splash', 'a:3:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1524762950;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}s:18:"nav_menu_locations";a:0:{}}', 'yes'),
(239, 'cpac_options_page__default', 'a:10:{s:2:"cb";s:25:"<input type="checkbox" />";s:5:"title";s:5:"Title";s:6:"author";s:6:"Author";s:8:"comments";s:111:"<span class="vers comment-grey-bubble" title="Comments"><span class="screen-reader-text">Comments</span></span>";s:4:"date";s:4:"Date";s:11:"wpseo-score";s:3:"SEO";s:23:"wpseo-score-readability";s:11:"Readability";s:11:"wpseo-title";s:9:"SEO Title";s:14:"wpseo-metadesc";s:10:"Meta Desc.";s:13:"wpseo-focuskw";s:8:"Focus KW";}', 'yes'),
(240, 'wpseo_sitemap_1_cache_validator', '5w8Pk', 'no'),
(241, 'wpseo_sitemap_page_cache_validator', '5w8Po', 'no'),
(258, 'category_children', 'a:0:{}', 'yes'),
(281, 'cptui_post_types', 'a:1:{s:7:"student";a:28:{s:4:"name";s:7:"student";s:5:"label";s:8:"Students";s:14:"singular_label";s:7:"Student";s:11:"description";s:25:"post for student projects";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:12:"show_in_rest";s:5:"false";s:9:"rest_base";s:0:"";s:11:"has_archive";s:5:"false";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";s:8:"supports";a:5:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";i:3;s:13:"custom-fields";i:4;s:12:"post-formats";}s:10:"taxonomies";a:0:{}s:6:"labels";a:23:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:9:"view_item";s:0:"";s:10:"view_items";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:17:"parent_item_colon";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:8:"archives";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:10:"attributes";s:0:"";}s:15:"custom_supports";s:0:"";}}', 'yes'),
(284, 'cptui_taxonomies', 'a:1:{s:7:"student";a:21:{s:4:"name";s:7:"student";s:5:"label";s:8:"students";s:14:"singular_label";s:7:"student";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:12:"hierarchical";s:5:"false";s:7:"show_ui";s:4:"true";s:12:"show_in_menu";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:20:"rewrite_hierarchical";s:1:"0";s:17:"show_admin_column";s:5:"false";s:12:"show_in_rest";s:5:"false";s:18:"show_in_quick_edit";s:0:"";s:9:"rest_base";s:0:"";s:6:"labels";a:18:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:9:"edit_item";s:0:"";s:9:"view_item";s:0:"";s:11:"update_item";s:0:"";s:12:"add_new_item";s:0:"";s:13:"new_item_name";s:0:"";s:11:"parent_item";s:0:"";s:17:"parent_item_colon";s:0:"";s:12:"search_items";s:0:"";s:13:"popular_items";s:0:"";s:26:"separate_items_with_commas";s:0:"";s:19:"add_or_remove_items";s:0:"";s:21:"choose_from_most_used";s:0:"";s:9:"not_found";s:0:"";s:8:"no_terms";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";}s:12:"object_types";a:1:{i:0;s:7:"student";}}}', 'yes'),
(287, 'wpseo_sitemap_student_cache_validator', '5gFbX', 'no'),
(291, 'cpac_options_student__default', 'a:8:{s:2:"cb";s:25:"<input type="checkbox" />";s:5:"title";s:5:"Title";s:4:"date";s:4:"Date";s:11:"wpseo-score";s:3:"SEO";s:23:"wpseo-score-readability";s:11:"Readability";s:11:"wpseo-title";s:9:"SEO Title";s:14:"wpseo-metadesc";s:10:"Meta Desc.";s:13:"wpseo-focuskw";s:8:"Focus KW";}', 'yes'),
(306, 'theme_mods_portshowlio18', 'a:6:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1524764706;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}s:12:"header_image";s:70:"http://2018.portshowl.io/wp-content/uploads/2018/05/cropped-p_logo.png";s:17:"header_image_data";O:8:"stdClass":5:{s:13:"attachment_id";i:142;s:3:"url";s:70:"http://2018.portshowl.io/wp-content/uploads/2018/05/cropped-p_logo.png";s:13:"thumbnail_url";s:70:"http://2018.portshowl.io/wp-content/uploads/2018/05/cropped-p_logo.png";s:6:"height";i:1000;s:5:"width";i:1000;}}', 'yes'),
(380, 'wpseo_sitemap_post_cache_validator', '5Dpi5', 'no'),
(413, 'cpac_options_post__default', 'a:12:{s:2:"cb";s:25:"<input type="checkbox" />";s:5:"title";s:5:"Title";s:6:"author";s:6:"Author";s:10:"categories";s:10:"Categories";s:4:"tags";s:4:"Tags";s:8:"comments";s:111:"<span class="vers comment-grey-bubble" title="Comments"><span class="screen-reader-text">Comments</span></span>";s:4:"date";s:4:"Date";s:11:"wpseo-score";s:3:"SEO";s:23:"wpseo-score-readability";s:11:"Readability";s:11:"wpseo-title";s:9:"SEO Title";s:14:"wpseo-metadesc";s:10:"Meta Desc.";s:13:"wpseo-focuskw";s:8:"Focus KW";}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=901 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(31, 14, '_edit_last', '1'),
(32, 14, '_wp_page_template', 'front-page.php'),
(33, 14, '_edit_lock', '1525972688:1'),
(34, 17, '_wp_attached_file', '2018/04/01-arctic-fox-den.adapt_.1900.1.jpg'),
(35, 17, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1900;s:6:"height";i:1278;s:4:"file";s:43:"2018/04/01-arctic-fox-den.adapt_.1900.1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:43:"01-arctic-fox-den.adapt_.1900.1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:43:"01-arctic-fox-den.adapt_.1900.1-300x202.jpg";s:5:"width";i:300;s:6:"height";i:202;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:43:"01-arctic-fox-den.adapt_.1900.1-768x517.jpg";s:5:"width";i:768;s:6:"height";i:517;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:44:"01-arctic-fox-den.adapt_.1900.1-1024x689.jpg";s:5:"width";i:1024;s:6:"height";i:689;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(36, 14, '_thumbnail_id', '17'),
(39, 19, '_wp_trash_meta_status', 'publish'),
(40, 19, '_wp_trash_meta_time', '1523503667'),
(41, 20, '_edit_last', '1'),
(42, 20, '_edit_lock', '1525972607:1'),
(43, 14, 'description', 'The graduating class of Seattle Central Creative Academy is proud to present Portshowlio 2018. This group of talented graduates is anything but one-dimensional. This show captures the many facets of their collaboration and dedication. Test!'),
(44, 14, '_description', 'field_5aced5291c62b'),
(45, 14, '_yoast_wpseo_content_score', '30'),
(46, 22, 'description', 'The graduating class of Seattle Central Creative Academy is proud to present Portshowlio 2017. From photography to design, this group of talented graduates is anything but one-dimensional. This show captures the many facets of their collaboration and dedication.'),
(47, 22, '_description', 'field_5aced5291c62b'),
(48, 23, 'description', 'The graduating class of Seattle Central Creative Academy is proud to present Portshowlio 2018. This group of talented graduates is anything but one-dimensional. This show captures the many facets of their collaboration and dedication.'),
(49, 23, '_description', 'field_5aced5291c62b'),
(50, 33, 'description', 'The graduating class of Seattle Central Creative Academy is proud to present Portshowlio 2018. This group of talented graduates is anything but one-dimensional. This show captures the many facets of their collaboration and dedication.'),
(51, 33, '_description', 'field_5aced5291c62b'),
(52, 33, 'day_1_title', 'Professional Night'),
(53, 33, '_day_1_title', 'field_5aced850d76fa'),
(54, 33, 'day_1_date', 'June 14th'),
(55, 33, '_day_1_date', 'field_5aced85cd76fb'),
(56, 33, 'day_', '6-9pm'),
(57, 33, '_day_', 'field_5aced865d76fc'),
(58, 33, 'day_2_title', 'Friends & Family Night'),
(59, 33, '_day_2_title', 'field_5aced888d76fd'),
(60, 33, 'day_2_date', 'June 15th'),
(61, 33, '_day_2_date', 'field_5aced88ed76fe'),
(62, 33, 'day_2_time', '6-9pm'),
(63, 33, '_day_2_time', 'field_5aced894d76ff'),
(64, 33, 'facebook_link', 'http://facebook.com'),
(65, 33, '_facebook_link', 'field_5aced899d7700'),
(66, 33, 'insta_link', 'http://instagram.com'),
(67, 33, '_insta_link', 'field_5aced8a5d7701'),
(68, 33, 'twitter_link', 'http://twitter.com'),
(69, 33, '_twitter_link', 'field_5aced8b4d7702'),
(70, 14, 'day_1_title', 'Professional Night'),
(71, 14, '_day_1_title', 'field_5aced850d76fa'),
(72, 14, 'day_1_date', 'June 14th'),
(73, 14, '_day_1_date', 'field_5aced85cd76fb'),
(74, 14, 'day_', '6-9pm'),
(75, 14, '_day_', 'field_5aced865d76fc'),
(76, 14, 'day_2_title', 'Friends & Family Night'),
(77, 14, '_day_2_title', 'field_5aced888d76fd'),
(78, 14, 'day_2_date', 'June 15th'),
(79, 14, '_day_2_date', 'field_5aced88ed76fe'),
(80, 14, 'day_2_time', '6-9pm'),
(81, 14, '_day_2_time', 'field_5aced894d76ff'),
(82, 14, 'facebook_link', 'http://facebook.com'),
(83, 14, '_facebook_link', 'field_5aced899d7700'),
(84, 14, 'insta_link', 'http://instagram.com'),
(85, 14, '_insta_link', 'field_5aced8a5d7701'),
(86, 14, 'twitter_link', 'http://twitter.com'),
(87, 14, '_twitter_link', 'field_5aced8b4d7702'),
(88, 34, 'description', 'The graduating class of Seattle Central Creative Academy is proud to present Portshowlio 2018. This group of talented graduates is anything but one-dimensional. This show captures the many facets of their collaboration and dedication.'),
(89, 34, '_description', 'field_5aced5291c62b'),
(90, 34, 'day_1_title', 'Professional Night'),
(91, 34, '_day_1_title', 'field_5aced850d76fa'),
(92, 34, 'day_1_date', 'June 14th'),
(93, 34, '_day_1_date', 'field_5aced85cd76fb'),
(94, 34, 'day_1_time', '6-9pm'),
(95, 34, '_day_1_time', 'field_5aced865d76fc'),
(96, 34, 'day_2_title', 'Friends & Family Night'),
(97, 34, '_day_2_title', 'field_5aced888d76fd'),
(98, 34, 'day_2_date', 'June 15th'),
(99, 34, '_day_2_date', 'field_5aced88ed76fe'),
(100, 34, 'day_2_time', '6-9pm'),
(101, 34, '_day_2_time', 'field_5aced894d76ff'),
(102, 34, 'facebook_link', 'http://facebook.com'),
(103, 34, '_facebook_link', 'field_5aced899d7700'),
(104, 34, 'insta_link', 'http://instagram.com'),
(105, 34, '_insta_link', 'field_5aced8a5d7701'),
(106, 34, 'twitter_link', 'http://twitter.com'),
(107, 34, '_twitter_link', 'field_5aced8b4d7702'),
(108, 14, 'day_1_time', '6-9pm'),
(109, 14, '_day_1_time', 'field_5aced865d76fc'),
(110, 37, '_edit_last', '1'),
(111, 37, '_yoast_wpseo_content_score', '30'),
(112, 37, '_edit_lock', '1525673951:1'),
(113, 38, '_edit_last', '1'),
(114, 38, '_edit_lock', '1525844037:1'),
(115, 43, '_wp_attached_file', '2018/04/kangoroo.jpg'),
(116, 43, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:699;s:6:"height";i:519;s:4:"file";s:20:"2018/04/kangoroo.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"kangoroo-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"kangoroo-300x223.jpg";s:5:"width";i:300;s:6:"height";i:223;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(117, 44, '_wp_attached_file', '2018/04/memay2016.jpg'),
(118, 44, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:958;s:6:"height";i:959;s:4:"file";s:21:"2018/04/memay2016.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"memay2016-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"memay2016-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"memay2016-768x769.jpg";s:5:"width";i:768;s:6:"height";i:769;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(119, 45, '_wp_attached_file', '2018/04/memay2016-1.jpg'),
(120, 45, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:958;s:6:"height";i:959;s:4:"file";s:23:"2018/04/memay2016-1.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"memay2016-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"memay2016-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"memay2016-1-768x769.jpg";s:5:"width";i:768;s:6:"height";i:769;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(121, 46, '_wp_attached_file', '2018/04/cats3.jpg'),
(122, 46, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:483;s:4:"file";s:17:"2018/04/cats3.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"cats3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"cats3-300x242.jpg";s:5:"width";i:300;s:6:"height";i:242;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(123, 37, 'student_photo', '88'),
(124, 37, '_student_photo', 'field_5acf9e173b70f'),
(125, 37, '_', 'field_5acf9e2f3b710'),
(126, 37, 'student_name', 'Student 1 Name'),
(127, 37, '_student_name', 'field_5acf9e98f8c6a'),
(128, 37, 'student_website', ''),
(129, 37, '_student_website', 'field_5acf9ea7f8c6b'),
(130, 37, 'project_1_title', 'Student 1 Project 1'),
(131, 37, '_project_1_title', 'field_5acfa7c0f2d80') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(132, 37, 'project_1_collaborator', ''),
(133, 37, '_project_1_collaborator', 'field_5acfa7d1f2d81'),
(134, 37, 'project_1_description', 'This is a test description for the magazine project.'),
(135, 37, '_project_1_description', 'field_5acfa7ddf2d82'),
(136, 37, 'project_1_image_1', '122'),
(137, 37, '_project_1_image_1', 'field_5acfa7e7f2d83'),
(138, 37, 'project_1_image_2', ''),
(139, 37, '_project_1_image_2', 'field_5acfa7faf2d84'),
(140, 37, 'project_1_image_3', ''),
(141, 37, '_project_1_image_3', 'field_5acfa805f2d85'),
(142, 37, 'student_twitter', 'https://twitter.com'),
(143, 37, '_student_twitter', 'field_5acfac89103c1'),
(144, 37, 'student_instagram', 'https://instagram.com'),
(145, 37, '_student_instagram', 'field_5acfaca1103c2'),
(146, 37, 'student_facebook', 'https://facebook.com'),
(147, 37, '_student_facebook', 'field_5acfacbf103c3'),
(148, 37, 'student_pinterest', 'https://pinterest.com'),
(149, 37, '_student_pinterest', 'field_5acfacc8103c4'),
(150, 37, 'project_2_title', 'Project 2'),
(151, 37, '_project_2_title', 'field_5acfaf63008de'),
(152, 37, 'project_2_collaborator', 'Ivanna'),
(153, 37, '_project_2_collaborator', 'field_5acfaf6e008df'),
(154, 37, 'project_2_description', 'This is test project description 2'),
(155, 37, '_project_2_description', 'field_5acfb061008e0'),
(156, 37, 'project_2_image_1', '46'),
(157, 37, '_project_2_image_1', 'field_5acfb06c008e1'),
(158, 37, 'project_2_image_2', '17'),
(159, 37, '_project_2_image_2', 'field_5acfb1d1008e2'),
(160, 37, 'project_2_image_3', '43'),
(161, 37, '_project_2_image_3', 'field_5acfb1df008e3'),
(162, 37, 'project_3_title', 'Project 3 Title'),
(163, 37, '_project_3_title', 'field_5acfb1f2008e4'),
(164, 37, 'project_3_collaborator', 'Newie'),
(165, 37, '_project_3_collaborator', 'field_5acfb1fa008e5'),
(166, 37, 'project_3_description', 'Test description for project 3'),
(167, 37, '_project_3_description', 'field_5acfb202008e6'),
(168, 37, 'project_3_image_1', '17'),
(169, 37, '_project_3_image_1', 'field_5acfb20d008e7'),
(170, 37, 'project_3_image_2', '43'),
(171, 37, '_project_3_image_2', 'field_5acfb21a008e8'),
(172, 37, 'project_3_image_3', '43'),
(173, 37, '_project_3_image_3', 'field_5acfb229008e9'),
(174, 37, 'student_category_1', 'Illustration'),
(175, 37, '_student_category_1', 'field_5acfbb2aa9042'),
(176, 37, 'student_category_2', 'UX / UI'),
(177, 37, '_student_category_2', 'field_5acfbb47a9043'),
(178, 37, 'student_category_3', 'Branding'),
(179, 37, '_student_category_3', 'field_5acfbb60a9044'),
(180, 2, '_edit_lock', '1524007989:1'),
(181, 73, 'description', 'The graduating class of Seattle Central Creative Academy is proud to present Portshowlio 2018. This group of talented graduates is anything but one-dimensional. This show captures the many facets of their collaboration and dedication. Test!'),
(182, 73, '_description', 'field_5aced5291c62b'),
(183, 73, 'day_1_title', 'Professional Night'),
(184, 73, '_day_1_title', 'field_5aced850d76fa'),
(185, 73, 'day_1_date', 'June 14th'),
(186, 73, '_day_1_date', 'field_5aced85cd76fb'),
(187, 73, 'day_1_time', '6-9pm'),
(188, 73, '_day_1_time', 'field_5aced865d76fc'),
(189, 73, 'day_2_title', 'Friends & Family Night'),
(190, 73, '_day_2_title', 'field_5aced888d76fd'),
(191, 73, 'day_2_date', 'June 15th'),
(192, 73, '_day_2_date', 'field_5aced88ed76fe'),
(193, 73, 'day_2_time', '6-9pm'),
(194, 73, '_day_2_time', 'field_5aced894d76ff'),
(195, 73, 'facebook_link', 'http://facebook.com'),
(196, 73, '_facebook_link', 'field_5aced899d7700'),
(197, 73, 'insta_link', 'http://instagram.com'),
(198, 73, '_insta_link', 'field_5aced8a5d7701'),
(199, 73, 'twitter_link', 'http://twitter.com'),
(200, 73, '_twitter_link', 'field_5aced8b4d7702'),
(201, 74, '_wp_attached_file', '2018/04/logo_placeholder.svg'),
(202, 77, '_edit_last', '1'),
(203, 77, '_edit_lock', '1525882708:1'),
(204, 77, 'student_photo', '94'),
(205, 77, '_student_photo', 'field_5acf9e173b70f'),
(206, 77, '_', 'field_5acf9e2f3b710'),
(207, 77, 'student_name', 'Student 2 Name'),
(208, 77, '_student_name', 'field_5acf9e98f8c6a'),
(209, 77, 'student_website', ''),
(210, 77, '_student_website', 'field_5acf9ea7f8c6b'),
(211, 77, 'project_1_title', 'Student 2 Project 1'),
(212, 77, '_project_1_title', 'field_5acfa7c0f2d80'),
(213, 77, 'project_1_collaborator', ''),
(214, 77, '_project_1_collaborator', 'field_5acfa7d1f2d81'),
(215, 77, 'project_1_description', 'Hello Fox!'),
(216, 77, '_project_1_description', 'field_5acfa7ddf2d82'),
(217, 77, 'project_1_image_1', '134'),
(218, 77, '_project_1_image_1', 'field_5acfa7e7f2d83'),
(219, 77, 'project_1_image_2', ''),
(220, 77, '_project_1_image_2', 'field_5acfa7faf2d84'),
(221, 77, 'project_1_image_3', ''),
(222, 77, '_project_1_image_3', 'field_5acfa805f2d85'),
(223, 77, 'student_twitter', ''),
(224, 77, '_student_twitter', 'field_5acfac89103c1'),
(225, 77, 'student_instagram', ''),
(226, 77, '_student_instagram', 'field_5acfaca1103c2'),
(227, 77, 'student_facebook', ''),
(228, 77, '_student_facebook', 'field_5acfacbf103c3'),
(229, 77, 'student_pinterest', ''),
(230, 77, '_student_pinterest', 'field_5acfacc8103c4'),
(231, 77, 'project_2_title', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(232, 77, '_project_2_title', 'field_5acfaf63008de'),
(233, 77, 'project_2_description', ''),
(234, 77, '_project_2_description', 'field_5acfb061008e0'),
(235, 77, 'project_2_image_1', ''),
(236, 77, '_project_2_image_1', 'field_5acfb06c008e1'),
(237, 77, 'project_2_image_2', ''),
(238, 77, '_project_2_image_2', 'field_5acfb1d1008e2'),
(239, 77, 'project_2_image_3', ''),
(240, 77, '_project_2_image_3', 'field_5acfb1df008e3'),
(241, 77, 'project_3_title', ''),
(242, 77, '_project_3_title', 'field_5acfb1f2008e4'),
(243, 77, 'project_3_collaborator', ''),
(244, 77, '_project_3_collaborator', 'field_5acfb1fa008e5'),
(245, 77, 'project_3_description', ''),
(246, 77, '_project_3_description', 'field_5acfb202008e6'),
(247, 77, 'project_3_image_1', ''),
(248, 77, '_project_3_image_1', 'field_5acfb20d008e7'),
(249, 77, 'project_3_image_2', ''),
(250, 77, '_project_3_image_2', 'field_5acfb21a008e8'),
(251, 77, 'project_3_image_3', ''),
(252, 77, '_project_3_image_3', 'field_5acfb229008e9'),
(253, 77, 'student_category_1', 'Advertising'),
(254, 77, '_student_category_1', 'field_5acfbb2aa9042'),
(255, 77, 'student_category_2', 'Virtual Reality'),
(256, 77, '_student_category_2', 'field_5acfbb47a9043'),
(257, 77, 'student_category_3', 'Motion Graphics'),
(258, 77, '_student_category_3', 'field_5acfbb60a9044'),
(259, 77, '_yoast_wpseo_content_score', '30'),
(260, 78, '_edit_last', '1'),
(261, 78, '_edit_lock', '1525882714:1'),
(262, 79, '_wp_attached_file', '2018/04/PICT0003.jpg'),
(263, 79, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2419;s:6:"height";i:3000;s:4:"file";s:20:"2018/04/PICT0003.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"PICT0003-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"PICT0003-242x300.jpg";s:5:"width";i:242;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"PICT0003-768x952.jpg";s:5:"width";i:768;s:6:"height";i:952;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"PICT0003-826x1024.jpg";s:5:"width";i:826;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:14:"Copyright 2012";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(264, 80, '_wp_attached_file', '2018/04/PICT0017.jpg'),
(265, 80, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1900;s:6:"height";i:2500;s:4:"file";s:20:"2018/04/PICT0017.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"PICT0017-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"PICT0017-228x300.jpg";s:5:"width";i:228;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"PICT0017-768x1011.jpg";s:5:"width";i:768;s:6:"height";i:1011;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"PICT0017-778x1024.jpg";s:5:"width";i:778;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:14:"Copyright 2012";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(266, 81, '_wp_attached_file', '2018/04/PICT0047.jpg'),
(267, 81, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2500;s:6:"height";i:1750;s:4:"file";s:20:"2018/04/PICT0047.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"PICT0047-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"PICT0047-300x210.jpg";s:5:"width";i:300;s:6:"height";i:210;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"PICT0047-768x538.jpg";s:5:"width";i:768;s:6:"height";i:538;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"PICT0047-1024x717.jpg";s:5:"width";i:1024;s:6:"height";i:717;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:14:"Copyright 2012";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(268, 82, '_wp_attached_file', '2018/04/PICT0055.jpg'),
(269, 82, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:2500;s:4:"file";s:20:"2018/04/PICT0055.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"PICT0055-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"PICT0055-240x300.jpg";s:5:"width";i:240;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"PICT0055-768x960.jpg";s:5:"width";i:768;s:6:"height";i:960;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"PICT0055-819x1024.jpg";s:5:"width";i:819;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:14:"Copyright 2012";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(270, 83, '_wp_attached_file', '2018/04/PICT0056.jpg'),
(271, 83, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1320;s:4:"file";s:20:"2018/04/PICT0056.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"PICT0056-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"PICT0056-300x198.jpg";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"PICT0056-768x507.jpg";s:5:"width";i:768;s:6:"height";i:507;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"PICT0056-1024x676.jpg";s:5:"width";i:1024;s:6:"height";i:676;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:14:"Copyright 2012";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(272, 84, '_wp_attached_file', '2018/04/PICT0057.jpg'),
(273, 84, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1900;s:6:"height";i:2500;s:4:"file";s:20:"2018/04/PICT0057.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"PICT0057-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"PICT0057-228x300.jpg";s:5:"width";i:228;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"PICT0057-768x1011.jpg";s:5:"width";i:768;s:6:"height";i:1011;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"PICT0057-778x1024.jpg";s:5:"width";i:778;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:14:"Copyright 2012";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(274, 85, '_wp_attached_file', '2018/04/PICT0061.jpg'),
(275, 85, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2500;s:6:"height";i:1827;s:4:"file";s:20:"2018/04/PICT0061.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"PICT0061-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"PICT0061-300x219.jpg";s:5:"width";i:300;s:6:"height";i:219;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"PICT0061-768x561.jpg";s:5:"width";i:768;s:6:"height";i:561;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"PICT0061-1024x748.jpg";s:5:"width";i:1024;s:6:"height";i:748;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:14:"Copyright 2012";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(276, 78, 'student_photo', '43'),
(277, 78, '_student_photo', 'field_5acf9e173b70f'),
(278, 78, '_', 'field_5acf9e2f3b710'),
(279, 78, 'student_name', 'Student 3 Name'),
(280, 78, '_student_name', 'field_5acf9e98f8c6a'),
(281, 78, 'student_website', ''),
(282, 78, '_student_website', 'field_5acf9ea7f8c6b'),
(283, 78, 'project_1_title', 'Project 1 Student 3'),
(284, 78, '_project_1_title', 'field_5acfa7c0f2d80'),
(285, 78, 'project_1_collaborator', ''),
(286, 78, '_project_1_collaborator', 'field_5acfa7d1f2d81'),
(287, 78, 'project_1_description', 'Student\'s 3 project'),
(288, 78, '_project_1_description', 'field_5acfa7ddf2d82'),
(289, 78, 'project_1_image_1', '133'),
(290, 78, '_project_1_image_1', 'field_5acfa7e7f2d83'),
(291, 78, 'project_1_image_2', ''),
(292, 78, '_project_1_image_2', 'field_5acfa7faf2d84'),
(293, 78, 'project_1_image_3', ''),
(294, 78, '_project_1_image_3', 'field_5acfa805f2d85'),
(295, 78, 'student_twitter', ''),
(296, 78, '_student_twitter', 'field_5acfac89103c1'),
(297, 78, 'student_instagram', ''),
(298, 78, '_student_instagram', 'field_5acfaca1103c2'),
(299, 78, 'student_facebook', ''),
(300, 78, '_student_facebook', 'field_5acfacbf103c3'),
(301, 78, 'student_pinterest', ''),
(302, 78, '_student_pinterest', 'field_5acfacc8103c4'),
(303, 78, 'project_2_title', ''),
(304, 78, '_project_2_title', 'field_5acfaf63008de'),
(305, 78, 'project_2_description', ''),
(306, 78, '_project_2_description', 'field_5acfb061008e0'),
(307, 78, 'project_2_image_1', ''),
(308, 78, '_project_2_image_1', 'field_5acfb06c008e1'),
(309, 78, 'project_2_image_2', ''),
(310, 78, '_project_2_image_2', 'field_5acfb1d1008e2'),
(311, 78, 'project_2_image_3', ''),
(312, 78, '_project_2_image_3', 'field_5acfb1df008e3'),
(313, 78, 'project_3_title', ''),
(314, 78, '_project_3_title', 'field_5acfb1f2008e4'),
(315, 78, 'project_3_collaborator', ''),
(316, 78, '_project_3_collaborator', 'field_5acfb1fa008e5'),
(317, 78, 'project_3_description', ''),
(318, 78, '_project_3_description', 'field_5acfb202008e6'),
(319, 78, 'project_3_image_1', ''),
(320, 78, '_project_3_image_1', 'field_5acfb20d008e7'),
(321, 78, 'project_3_image_2', ''),
(322, 78, '_project_3_image_2', 'field_5acfb21a008e8'),
(323, 78, 'project_3_image_3', ''),
(324, 78, '_project_3_image_3', 'field_5acfb229008e9'),
(325, 78, 'student_category_1', 'Advertising'),
(326, 78, '_student_category_1', 'field_5acfbb2aa9042'),
(327, 78, 'student_category_2', 'Branding'),
(328, 78, '_student_category_2', 'field_5acfbb47a9043'),
(329, 78, 'student_category_3', 'Motion Graphics'),
(330, 78, '_student_category_3', 'field_5acfbb60a9044'),
(331, 78, '_yoast_wpseo_content_score', '30') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(332, 86, '_wp_attached_file', '2018/04/cute-animals-5-animals-9403312-650-456.jpg'),
(333, 86, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:650;s:6:"height";i:456;s:4:"file";s:50:"2018/04/cute-animals-5-animals-9403312-650-456.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:50:"cute-animals-5-animals-9403312-650-456-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:50:"cute-animals-5-animals-9403312-650-456-300x210.jpg";s:5:"width";i:300;s:6:"height";i:210;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(334, 87, '_wp_attached_file', '2018/04/cute-animals-hokkaido-ezo-japan-5.jpg'),
(335, 87, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:880;s:6:"height";i:586;s:4:"file";s:45:"2018/04/cute-animals-hokkaido-ezo-japan-5.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:45:"cute-animals-hokkaido-ezo-japan-5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:45:"cute-animals-hokkaido-ezo-japan-5-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:45:"cute-animals-hokkaido-ezo-japan-5-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(336, 88, '_wp_attached_file', '2018/04/Cute-Animals3.jpg'),
(337, 88, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:593;s:6:"height";i:372;s:4:"file";s:25:"2018/04/Cute-Animals3.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Cute-Animals3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"Cute-Animals3-300x188.jpg";s:5:"width";i:300;s:6:"height";i:188;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(338, 89, '_wp_attached_file', '2018/04/lots-of-cute-animals-5-1.jpg'),
(339, 89, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:447;s:4:"file";s:36:"2018/04/lots-of-cute-animals-5-1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:36:"lots-of-cute-animals-5-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:36:"lots-of-cute-animals-5-1-300x210.jpg";s:5:"width";i:300;s:6:"height";i:210;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(340, 90, '_wp_attached_file', '2018/04/Top-20-Worlds-Cutest-Animals.jpg'),
(341, 90, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:667;s:4:"file";s:40:"2018/04/Top-20-Worlds-Cutest-Animals.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:40:"Top-20-Worlds-Cutest-Animals-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:40:"Top-20-Worlds-Cutest-Animals-288x300.jpg";s:5:"width";i:288;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(342, 91, '_wp_attached_file', '2018/04/MZ-7AaQh_400x400.jpg'),
(343, 91, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:400;s:4:"file";s:28:"2018/04/MZ-7AaQh_400x400.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"MZ-7AaQh_400x400-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"MZ-7AaQh_400x400-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(344, 92, '_wp_attached_file', '2018/04/enhanced-5913-1415212088-2.jpg'),
(345, 92, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:483;s:4:"file";s:38:"2018/04/enhanced-5913-1415212088-2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:38:"enhanced-5913-1415212088-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:38:"enhanced-5913-1415212088-2-300x242.jpg";s:5:"width";i:300;s:6:"height";i:242;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(346, 93, '_wp_attached_file', '2018/04/cute-baby-animals-13.jpg'),
(347, 93, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:605;s:6:"height";i:454;s:4:"file";s:32:"2018/04/cute-baby-animals-13.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"cute-baby-animals-13-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"cute-baby-animals-13-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(348, 94, '_wp_attached_file', '2018/04/cute-baby-animals-10.jpg'),
(349, 94, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:605;s:6:"height";i:422;s:4:"file";s:32:"2018/04/cute-baby-animals-10.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"cute-baby-animals-10-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"cute-baby-animals-10-300x209.jpg";s:5:"width";i:300;s:6:"height";i:209;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(350, 95, '_edit_last', '1'),
(351, 95, '_edit_lock', '1525882729:1'),
(352, 95, 'student_photo', '87'),
(353, 95, '_student_photo', 'field_5acf9e173b70f'),
(354, 95, '_', 'field_5acf9e2f3b710'),
(355, 95, 'student_name', 'Student 4 Name'),
(356, 95, '_student_name', 'field_5acf9e98f8c6a'),
(357, 95, 'student_website', ''),
(358, 95, '_student_website', 'field_5acf9ea7f8c6b'),
(359, 95, 'project_1_title', 'Student 4 Project 1'),
(360, 95, '_project_1_title', 'field_5acfa7c0f2d80'),
(361, 95, 'project_1_collaborator', ''),
(362, 95, '_project_1_collaborator', 'field_5acfa7d1f2d81'),
(363, 95, 'project_1_description', ''),
(364, 95, '_project_1_description', 'field_5acfa7ddf2d82'),
(365, 95, 'project_1_image_1', '130'),
(366, 95, '_project_1_image_1', 'field_5acfa7e7f2d83'),
(367, 95, 'project_1_image_2', ''),
(368, 95, '_project_1_image_2', 'field_5acfa7faf2d84'),
(369, 95, 'project_1_image_3', ''),
(370, 95, '_project_1_image_3', 'field_5acfa805f2d85'),
(371, 95, 'student_twitter', ''),
(372, 95, '_student_twitter', 'field_5acfac89103c1'),
(373, 95, 'student_instagram', ''),
(374, 95, '_student_instagram', 'field_5acfaca1103c2'),
(375, 95, 'student_facebook', ''),
(376, 95, '_student_facebook', 'field_5acfacbf103c3'),
(377, 95, 'student_pinterest', ''),
(378, 95, '_student_pinterest', 'field_5acfacc8103c4'),
(379, 95, 'project_2_title', ''),
(380, 95, '_project_2_title', 'field_5acfaf63008de'),
(381, 95, 'project_2_description', ''),
(382, 95, '_project_2_description', 'field_5acfb061008e0'),
(383, 95, 'project_2_image_1', ''),
(384, 95, '_project_2_image_1', 'field_5acfb06c008e1'),
(385, 95, 'project_2_image_2', ''),
(386, 95, '_project_2_image_2', 'field_5acfb1d1008e2'),
(387, 95, 'project_2_image_3', ''),
(388, 95, '_project_2_image_3', 'field_5acfb1df008e3'),
(389, 95, 'project_3_title', ''),
(390, 95, '_project_3_title', 'field_5acfb1f2008e4'),
(391, 95, 'project_3_collaborator', ''),
(392, 95, '_project_3_collaborator', 'field_5acfb1fa008e5'),
(393, 95, 'project_3_description', ''),
(394, 95, '_project_3_description', 'field_5acfb202008e6'),
(395, 95, 'project_3_image_1', ''),
(396, 95, '_project_3_image_1', 'field_5acfb20d008e7'),
(397, 95, 'project_3_image_2', ''),
(398, 95, '_project_3_image_2', 'field_5acfb21a008e8'),
(399, 95, 'project_3_image_3', ''),
(400, 95, '_project_3_image_3', 'field_5acfb229008e9'),
(401, 95, 'student_category_1', 'Layout'),
(402, 95, '_student_category_1', 'field_5acfbb2aa9042'),
(403, 95, 'student_category_2', 'Illustration'),
(404, 95, '_student_category_2', 'field_5acfbb47a9043'),
(405, 95, 'student_category_3', 'Advertising'),
(406, 95, '_student_category_3', 'field_5acfbb60a9044'),
(407, 95, '_yoast_wpseo_content_score', '30'),
(408, 96, '_edit_last', '1'),
(409, 96, '_edit_lock', '1525882737:1'),
(410, 96, 'student_photo', '92'),
(411, 96, '_student_photo', 'field_5acf9e173b70f'),
(412, 96, '_', 'field_5acf9e2f3b710'),
(413, 96, 'student_name', 'Student 5 Name'),
(414, 96, '_student_name', 'field_5acf9e98f8c6a'),
(415, 96, 'student_website', ''),
(416, 96, '_student_website', 'field_5acf9ea7f8c6b'),
(417, 96, 'project_1_title', 'Student 5 Project 1'),
(418, 96, '_project_1_title', 'field_5acfa7c0f2d80'),
(419, 96, 'project_1_collaborator', ''),
(420, 96, '_project_1_collaborator', 'field_5acfa7d1f2d81'),
(421, 96, 'project_1_description', ''),
(422, 96, '_project_1_description', 'field_5acfa7ddf2d82'),
(423, 96, 'project_1_image_1', '125'),
(424, 96, '_project_1_image_1', 'field_5acfa7e7f2d83'),
(425, 96, 'project_1_image_2', ''),
(426, 96, '_project_1_image_2', 'field_5acfa7faf2d84'),
(427, 96, 'project_1_image_3', ''),
(428, 96, '_project_1_image_3', 'field_5acfa805f2d85'),
(429, 96, 'student_twitter', ''),
(430, 96, '_student_twitter', 'field_5acfac89103c1'),
(431, 96, 'student_instagram', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(432, 96, '_student_instagram', 'field_5acfaca1103c2'),
(433, 96, 'student_facebook', ''),
(434, 96, '_student_facebook', 'field_5acfacbf103c3'),
(435, 96, 'student_pinterest', ''),
(436, 96, '_student_pinterest', 'field_5acfacc8103c4'),
(437, 96, 'project_2_title', ''),
(438, 96, '_project_2_title', 'field_5acfaf63008de'),
(439, 96, 'project_2_description', ''),
(440, 96, '_project_2_description', 'field_5acfb061008e0'),
(441, 96, 'project_2_image_1', ''),
(442, 96, '_project_2_image_1', 'field_5acfb06c008e1'),
(443, 96, 'project_2_image_2', ''),
(444, 96, '_project_2_image_2', 'field_5acfb1d1008e2'),
(445, 96, 'project_2_image_3', ''),
(446, 96, '_project_2_image_3', 'field_5acfb1df008e3'),
(447, 96, 'project_3_title', ''),
(448, 96, '_project_3_title', 'field_5acfb1f2008e4'),
(449, 96, 'project_3_collaborator', ''),
(450, 96, '_project_3_collaborator', 'field_5acfb1fa008e5'),
(451, 96, 'project_3_description', ''),
(452, 96, '_project_3_description', 'field_5acfb202008e6'),
(453, 96, 'project_3_image_1', ''),
(454, 96, '_project_3_image_1', 'field_5acfb20d008e7'),
(455, 96, 'project_3_image_2', ''),
(456, 96, '_project_3_image_2', 'field_5acfb21a008e8'),
(457, 96, 'project_3_image_3', ''),
(458, 96, '_project_3_image_3', 'field_5acfb229008e9'),
(459, 96, 'student_category_1', 'Advertising'),
(460, 96, '_student_category_1', 'field_5acfbb2aa9042'),
(461, 96, 'student_category_2', 'Typography'),
(462, 96, '_student_category_2', 'field_5acfbb47a9043'),
(463, 96, 'student_category_3', 'Layout'),
(464, 96, '_student_category_3', 'field_5acfbb60a9044'),
(465, 96, '_yoast_wpseo_content_score', '30'),
(466, 97, '_edit_last', '1'),
(467, 97, '_edit_lock', '1525882756:1'),
(468, 97, 'student_photo', '90'),
(469, 97, '_student_photo', 'field_5acf9e173b70f'),
(470, 97, '_', 'field_5acf9e2f3b710'),
(471, 97, 'student_name', 'Student 6 Name'),
(472, 97, '_student_name', 'field_5acf9e98f8c6a'),
(473, 97, 'student_website', ''),
(474, 97, '_student_website', 'field_5acf9ea7f8c6b'),
(475, 97, 'project_1_title', 'Project 1 Student 6'),
(476, 97, '_project_1_title', 'field_5acfa7c0f2d80'),
(477, 97, 'project_1_collaborator', ''),
(478, 97, '_project_1_collaborator', 'field_5acfa7d1f2d81'),
(479, 97, 'project_1_description', 'Student 6 Project 1'),
(480, 97, '_project_1_description', 'field_5acfa7ddf2d82'),
(481, 97, 'project_1_image_1', '135'),
(482, 97, '_project_1_image_1', 'field_5acfa7e7f2d83'),
(483, 97, 'project_1_image_2', ''),
(484, 97, '_project_1_image_2', 'field_5acfa7faf2d84'),
(485, 97, 'project_1_image_3', ''),
(486, 97, '_project_1_image_3', 'field_5acfa805f2d85'),
(487, 97, 'student_twitter', ''),
(488, 97, '_student_twitter', 'field_5acfac89103c1'),
(489, 97, 'student_instagram', ''),
(490, 97, '_student_instagram', 'field_5acfaca1103c2'),
(491, 97, 'student_facebook', ''),
(492, 97, '_student_facebook', 'field_5acfacbf103c3'),
(493, 97, 'student_pinterest', ''),
(494, 97, '_student_pinterest', 'field_5acfacc8103c4'),
(495, 97, 'project_2_title', ''),
(496, 97, '_project_2_title', 'field_5acfaf63008de'),
(497, 97, 'project_2_description', ''),
(498, 97, '_project_2_description', 'field_5acfb061008e0'),
(499, 97, 'project_2_image_1', ''),
(500, 97, '_project_2_image_1', 'field_5acfb06c008e1'),
(501, 97, 'project_2_image_2', ''),
(502, 97, '_project_2_image_2', 'field_5acfb1d1008e2'),
(503, 97, 'project_2_image_3', ''),
(504, 97, '_project_2_image_3', 'field_5acfb1df008e3'),
(505, 97, 'project_3_title', ''),
(506, 97, '_project_3_title', 'field_5acfb1f2008e4'),
(507, 97, 'project_3_collaborator', ''),
(508, 97, '_project_3_collaborator', 'field_5acfb1fa008e5'),
(509, 97, 'project_3_description', ''),
(510, 97, '_project_3_description', 'field_5acfb202008e6'),
(511, 97, 'project_3_image_1', ''),
(512, 97, '_project_3_image_1', 'field_5acfb20d008e7'),
(513, 97, 'project_3_image_2', ''),
(514, 97, '_project_3_image_2', 'field_5acfb21a008e8'),
(515, 97, 'project_3_image_3', ''),
(516, 97, '_project_3_image_3', 'field_5acfb229008e9'),
(517, 97, 'student_category_1', 'Advertising'),
(518, 97, '_student_category_1', 'field_5acfbb2aa9042'),
(519, 97, 'student_category_2', 'Web Design'),
(520, 97, '_student_category_2', 'field_5acfbb47a9043'),
(521, 97, 'student_category_3', 'UX / UI'),
(522, 97, '_student_category_3', 'field_5acfbb60a9044'),
(523, 97, '_yoast_wpseo_content_score', '30'),
(524, 98, '_edit_last', '1'),
(525, 98, '_edit_lock', '1525882778:1'),
(526, 98, 'student_photo', '91'),
(527, 98, '_student_photo', 'field_5acf9e173b70f'),
(528, 98, '_', 'field_5acf9e2f3b710'),
(529, 98, 'student_name', 'Student 7 Name'),
(530, 98, '_student_name', 'field_5acf9e98f8c6a'),
(531, 98, 'student_website', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(532, 98, '_student_website', 'field_5acf9ea7f8c6b'),
(533, 98, 'project_1_title', 'Student 7 Project 1'),
(534, 98, '_project_1_title', 'field_5acfa7c0f2d80'),
(535, 98, 'project_1_collaborator', 'a:1:{i:0;s:2:"95";}'),
(536, 98, '_project_1_collaborator', 'field_5acfa7d1f2d81'),
(537, 98, 'project_1_description', 'student 7 project 1 desc'),
(538, 98, '_project_1_description', 'field_5acfa7ddf2d82'),
(539, 98, 'project_1_image_1', '126'),
(540, 98, '_project_1_image_1', 'field_5acfa7e7f2d83'),
(541, 98, 'project_1_image_2', ''),
(542, 98, '_project_1_image_2', 'field_5acfa7faf2d84'),
(543, 98, 'project_1_image_3', ''),
(544, 98, '_project_1_image_3', 'field_5acfa805f2d85'),
(545, 98, 'student_twitter', ''),
(546, 98, '_student_twitter', 'field_5acfac89103c1'),
(547, 98, 'student_instagram', ''),
(548, 98, '_student_instagram', 'field_5acfaca1103c2'),
(549, 98, 'student_facebook', ''),
(550, 98, '_student_facebook', 'field_5acfacbf103c3'),
(551, 98, 'student_pinterest', ''),
(552, 98, '_student_pinterest', 'field_5acfacc8103c4'),
(553, 98, 'project_2_title', ''),
(554, 98, '_project_2_title', 'field_5acfaf63008de'),
(555, 98, 'project_2_description', ''),
(556, 98, '_project_2_description', 'field_5acfb061008e0'),
(557, 98, 'project_2_image_1', ''),
(558, 98, '_project_2_image_1', 'field_5acfb06c008e1'),
(559, 98, 'project_2_image_2', ''),
(560, 98, '_project_2_image_2', 'field_5acfb1d1008e2'),
(561, 98, 'project_2_image_3', ''),
(562, 98, '_project_2_image_3', 'field_5acfb1df008e3'),
(563, 98, 'project_3_title', ''),
(564, 98, '_project_3_title', 'field_5acfb1f2008e4'),
(565, 98, 'project_3_collaborator', ''),
(566, 98, '_project_3_collaborator', 'field_5acfb1fa008e5'),
(567, 98, 'project_3_description', ''),
(568, 98, '_project_3_description', 'field_5acfb202008e6'),
(569, 98, 'project_3_image_1', ''),
(570, 98, '_project_3_image_1', 'field_5acfb20d008e7'),
(571, 98, 'project_3_image_2', ''),
(572, 98, '_project_3_image_2', 'field_5acfb21a008e8'),
(573, 98, 'project_3_image_3', ''),
(574, 98, '_project_3_image_3', 'field_5acfb229008e9'),
(575, 98, 'student_category_1', 'UX / UI'),
(576, 98, '_student_category_1', 'field_5acfbb2aa9042'),
(577, 98, 'student_category_2', 'Virtual Reality'),
(578, 98, '_student_category_2', 'field_5acfbb47a9043'),
(579, 98, 'student_category_3', 'Art Direction'),
(580, 98, '_student_category_3', 'field_5acfbb60a9044'),
(581, 98, '_yoast_wpseo_content_score', '30'),
(582, 99, '_edit_last', '1'),
(583, 99, '_edit_lock', '1525882938:1'),
(584, 99, 'student_photo', '86'),
(585, 99, '_student_photo', 'field_5acf9e173b70f'),
(586, 99, '_', 'field_5acf9e2f3b710'),
(587, 99, 'student_name', 'Student 8 Name'),
(588, 99, '_student_name', 'field_5acf9e98f8c6a'),
(589, 99, 'student_website', ''),
(590, 99, '_student_website', 'field_5acf9ea7f8c6b'),
(591, 99, 'project_1_title', 'Project 1 by student 8'),
(592, 99, '_project_1_title', 'field_5acfa7c0f2d80'),
(593, 99, 'project_1_collaborator', ''),
(594, 99, '_project_1_collaborator', 'field_5acfa7d1f2d81'),
(595, 99, 'project_1_description', ''),
(596, 99, '_project_1_description', 'field_5acfa7ddf2d82'),
(597, 99, 'project_1_image_1', '119'),
(598, 99, '_project_1_image_1', 'field_5acfa7e7f2d83'),
(599, 99, 'project_1_image_2', ''),
(600, 99, '_project_1_image_2', 'field_5acfa7faf2d84'),
(601, 99, 'project_1_image_3', ''),
(602, 99, '_project_1_image_3', 'field_5acfa805f2d85'),
(603, 99, 'student_twitter', ''),
(604, 99, '_student_twitter', 'field_5acfac89103c1'),
(605, 99, 'student_instagram', ''),
(606, 99, '_student_instagram', 'field_5acfaca1103c2'),
(607, 99, 'student_facebook', ''),
(608, 99, '_student_facebook', 'field_5acfacbf103c3'),
(609, 99, 'student_pinterest', ''),
(610, 99, '_student_pinterest', 'field_5acfacc8103c4'),
(611, 99, 'project_2_title', ''),
(612, 99, '_project_2_title', 'field_5acfaf63008de'),
(613, 99, 'project_2_description', ''),
(614, 99, '_project_2_description', 'field_5acfb061008e0'),
(615, 99, 'project_2_image_1', ''),
(616, 99, '_project_2_image_1', 'field_5acfb06c008e1'),
(617, 99, 'project_2_image_2', ''),
(618, 99, '_project_2_image_2', 'field_5acfb1d1008e2'),
(619, 99, 'project_2_image_3', ''),
(620, 99, '_project_2_image_3', 'field_5acfb1df008e3'),
(621, 99, 'project_3_title', ''),
(622, 99, '_project_3_title', 'field_5acfb1f2008e4'),
(623, 99, 'project_3_collaborator', ''),
(624, 99, '_project_3_collaborator', 'field_5acfb1fa008e5'),
(625, 99, 'project_3_description', ''),
(626, 99, '_project_3_description', 'field_5acfb202008e6'),
(627, 99, 'project_3_image_1', ''),
(628, 99, '_project_3_image_1', 'field_5acfb20d008e7'),
(629, 99, 'project_3_image_2', ''),
(630, 99, '_project_3_image_2', 'field_5acfb21a008e8'),
(631, 99, 'project_3_image_3', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(632, 99, '_project_3_image_3', 'field_5acfb229008e9'),
(633, 99, 'student_category_1', 'UX / UI'),
(634, 99, '_student_category_1', 'field_5acfbb2aa9042'),
(635, 99, 'student_category_2', 'Web Design'),
(636, 99, '_student_category_2', 'field_5acfbb47a9043'),
(637, 99, 'student_category_3', 'Advertising'),
(638, 99, '_student_category_3', 'field_5acfbb60a9044'),
(639, 99, '_yoast_wpseo_content_score', '30'),
(640, 100, '_menu_item_type', 'post_type'),
(641, 100, '_menu_item_menu_item_parent', '0'),
(642, 100, '_menu_item_object_id', '14'),
(643, 100, '_menu_item_object', 'page'),
(644, 100, '_menu_item_target', ''),
(645, 100, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(646, 100, '_menu_item_xfn', ''),
(647, 100, '_menu_item_url', ''),
(648, 100, '_menu_item_orphaned', '1524775590'),
(649, 101, '_menu_item_type', 'post_type'),
(650, 101, '_menu_item_menu_item_parent', '0'),
(651, 101, '_menu_item_object_id', '14'),
(652, 101, '_menu_item_object', 'page'),
(653, 101, '_menu_item_target', ''),
(654, 101, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(655, 101, '_menu_item_xfn', ''),
(656, 101, '_menu_item_url', ''),
(657, 101, '_menu_item_orphaned', '1524775590'),
(658, 102, '_menu_item_type', 'post_type'),
(659, 102, '_menu_item_menu_item_parent', '0'),
(660, 102, '_menu_item_object_id', '2'),
(661, 102, '_menu_item_object', 'page'),
(662, 102, '_menu_item_target', ''),
(663, 102, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(664, 102, '_menu_item_xfn', ''),
(665, 102, '_menu_item_url', ''),
(666, 102, '_menu_item_orphaned', '1524775590'),
(667, 103, '_edit_last', '1'),
(668, 103, '_edit_lock', '1525977622:1'),
(669, 105, '_wp_attached_file', '2018/04/Zig-Zag.svg'),
(670, 106, '_wp_attached_file', '2018/04/logopage.jpg'),
(671, 106, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1366;s:6:"height";i:768;s:4:"file";s:20:"2018/04/logopage.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"logopage-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"logopage-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"logopage-768x432.jpg";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"logopage-1024x576.jpg";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(672, 107, 'background_image', '106'),
(673, 107, '_background_image', 'field_5ae759c32faae'),
(674, 14, 'background_image', '106'),
(675, 14, '_background_image', 'field_5ae759c32faae'),
(676, 109, 'background_image', '106'),
(677, 109, '_background_image', 'field_5ae759c32faae'),
(678, 109, 'logonav', '105'),
(679, 109, '_logonav', 'field_5ae7683eabaca'),
(680, 14, 'logonav', '114'),
(681, 14, '_logonav', 'field_5ae7683eabaca'),
(682, 110, '_wp_attached_file', '2018/04/Zig-Zag-1.svg'),
(683, 111, '_wp_attached_file', '2018/04/Zig-Zag-2.svg'),
(684, 112, '_wp_attached_file', '2018/04/Dots.svg'),
(685, 113, '_wp_attached_file', '2018/04/Cheetos.svg'),
(686, 114, '_wp_attached_file', '2018/04/logonav_blackzz.svg'),
(687, 115, 'background_image', '106'),
(688, 115, '_background_image', 'field_5ae759c32faae'),
(689, 115, 'logonav', '114'),
(690, 115, '_logonav', 'field_5ae7683eabaca'),
(691, 116, '_wp_attached_file', '2018/05/logonav_blackzz.png'),
(692, 116, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:787;s:6:"height";i:691;s:4:"file";s:27:"2018/05/logonav_blackzz.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"logonav_blackzz-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"logonav_blackzz-300x263.png";s:5:"width";i:300;s:6:"height";i:263;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:27:"logonav_blackzz-768x674.png";s:5:"width";i:768;s:6:"height";i:674;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(693, 117, '_wp_attached_file', '2018/05/cropped-logonav_blackzz.png'),
(694, 117, '_wp_attachment_context', 'custom-header'),
(695, 117, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1000;s:6:"height";i:878;s:4:"file";s:35:"2018/05/cropped-logonav_blackzz.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:35:"cropped-logonav_blackzz-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:35:"cropped-logonav_blackzz-300x263.png";s:5:"width";i:300;s:6:"height";i:263;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:35:"cropped-logonav_blackzz-768x674.png";s:5:"width";i:768;s:6:"height";i:674;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:17:"attachment_parent";i:116;}'),
(696, 117, '_wp_attachment_custom_header_last_used_portshowlio18', '1525242228'),
(697, 117, '_wp_attachment_is_custom_header', 'portshowlio18'),
(698, 118, '_wp_trash_meta_status', 'publish'),
(699, 118, '_wp_trash_meta_time', '1525242228'),
(700, 119, '_wp_attached_file', '2018/04/moog.svg'),
(701, 120, '_wp_attached_file', '2018/04/stopbutton.svg'),
(702, 121, '_wp_attached_file', '2018/04/playbutton.svg'),
(703, 122, '_wp_attached_file', '2018/04/808.svg'),
(704, 123, '_wp_attached_file', '2018/04/909.svg'),
(705, 124, '_wp_attached_file', '2018/04/303.svg'),
(706, 125, '_wp_attached_file', '2018/04/buchla.svg'),
(707, 126, '_wp_attached_file', '2018/04/minimoog.svg'),
(708, 127, '_wp_attached_file', '2018/04/maq.svg'),
(709, 128, '_wp_attached_file', '2018/04/micro.svg'),
(710, 129, '_wp_attached_file', '2018/04/dx7.svg'),
(711, 130, '_wp_attached_file', '2018/04/fairlight.svg'),
(712, 131, '_wp_attached_file', '2018/04/hammond.svg'),
(713, 132, '_wp_attached_file', '2018/04/doepfera100.svg'),
(714, 133, '_wp_attached_file', '2018/04/theremin.svg'),
(715, 134, '_wp_attached_file', '2018/04/magnetophone.svg'),
(716, 135, '_wp_attached_file', '2018/04/tr-909.svg'),
(717, 136, '_edit_last', '1'),
(718, 136, '_edit_lock', '1525882562:1'),
(719, 137, '_wp_attached_file', '2018/05/01-arctic-fox-den.adapt_.1900.1.jpg'),
(720, 137, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1900;s:6:"height";i:1278;s:4:"file";s:43:"2018/05/01-arctic-fox-den.adapt_.1900.1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:43:"01-arctic-fox-den.adapt_.1900.1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:43:"01-arctic-fox-den.adapt_.1900.1-300x202.jpg";s:5:"width";i:300;s:6:"height";i:202;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:43:"01-arctic-fox-den.adapt_.1900.1-768x517.jpg";s:5:"width";i:768;s:6:"height";i:517;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:44:"01-arctic-fox-den.adapt_.1900.1-1024x689.jpg";s:5:"width";i:1024;s:6:"height";i:689;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(721, 138, '_wp_attached_file', '2018/05/cute-baby-animals-13.jpg'),
(722, 138, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:605;s:6:"height";i:454;s:4:"file";s:32:"2018/05/cute-baby-animals-13.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"cute-baby-animals-13-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"cute-baby-animals-13-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(723, 139, '_wp_attached_file', '2018/05/fox-1540833_1920.jpg'),
(724, 139, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:1280;s:4:"file";s:28:"2018/05/fox-1540833_1920.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"fox-1540833_1920-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"fox-1540833_1920-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"fox-1540833_1920-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"fox-1540833_1920-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"4";s:6:"credit";s:0:"";s:6:"camera";s:10:"DMC-FZ1000";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:6:"137.03";s:3:"iso";s:3:"400";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(725, 136, 'student_photo', '138'),
(726, 136, '_student_photo', 'field_5acf9e173b70f'),
(727, 136, '_', 'field_5acf9e2f3b710'),
(728, 136, 'student_name', 'Student 9 Name'),
(729, 136, '_student_name', 'field_5acf9e98f8c6a'),
(730, 136, 'student_website', ''),
(731, 136, '_student_website', 'field_5acf9ea7f8c6b') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(732, 136, 'project_1_title', 'Student 9 Project 1'),
(733, 136, '_project_1_title', 'field_5acfa7c0f2d80'),
(734, 136, 'project_1_collaborator', ''),
(735, 136, '_project_1_collaborator', 'field_5acfa7d1f2d81'),
(736, 136, 'project_1_description', ''),
(737, 136, '_project_1_description', 'field_5acfa7ddf2d82'),
(738, 136, 'project_1_image_1', '128'),
(739, 136, '_project_1_image_1', 'field_5acfa7e7f2d83'),
(740, 136, 'project_1_image_2', ''),
(741, 136, '_project_1_image_2', 'field_5acfa7faf2d84'),
(742, 136, 'project_1_image_3', ''),
(743, 136, '_project_1_image_3', 'field_5acfa805f2d85'),
(744, 136, 'student_twitter', ''),
(745, 136, '_student_twitter', 'field_5acfac89103c1'),
(746, 136, 'student_instagram', ''),
(747, 136, '_student_instagram', 'field_5acfaca1103c2'),
(748, 136, 'student_facebook', ''),
(749, 136, '_student_facebook', 'field_5acfacbf103c3'),
(750, 136, 'student_pinterest', ''),
(751, 136, '_student_pinterest', 'field_5acfacc8103c4'),
(752, 136, 'project_2_title', ''),
(753, 136, '_project_2_title', 'field_5acfaf63008de'),
(754, 136, 'project_2_description', ''),
(755, 136, '_project_2_description', 'field_5acfb061008e0'),
(756, 136, 'project_2_image_1', ''),
(757, 136, '_project_2_image_1', 'field_5acfb06c008e1'),
(758, 136, 'project_2_image_2', ''),
(759, 136, '_project_2_image_2', 'field_5acfb1d1008e2'),
(760, 136, 'project_2_image_3', ''),
(761, 136, '_project_2_image_3', 'field_5acfb1df008e3'),
(762, 136, 'project_3_title', ''),
(763, 136, '_project_3_title', 'field_5acfb1f2008e4'),
(764, 136, 'project_3_collaborator', ''),
(765, 136, '_project_3_collaborator', 'field_5acfb1fa008e5'),
(766, 136, 'project_3_description', ''),
(767, 136, '_project_3_description', 'field_5acfb202008e6'),
(768, 136, 'project_3_image_1', ''),
(769, 136, '_project_3_image_1', 'field_5acfb20d008e7'),
(770, 136, 'project_3_image_2', ''),
(771, 136, '_project_3_image_2', 'field_5acfb21a008e8'),
(772, 136, 'project_3_image_3', ''),
(773, 136, '_project_3_image_3', 'field_5acfb229008e9'),
(774, 136, 'student_category_1', 'Default'),
(775, 136, '_student_category_1', 'field_5acfbb2aa9042'),
(776, 136, 'student_category_2', 'UX / UI'),
(777, 136, '_student_category_2', 'field_5acfbb47a9043'),
(778, 136, 'student_category_3', 'Art Direction'),
(779, 136, '_student_category_3', 'field_5acfbb60a9044'),
(780, 136, '_yoast_wpseo_content_score', '30'),
(781, 140, '_edit_last', '1'),
(782, 140, '_edit_lock', '1525882537:1'),
(783, 140, 'student_photo', '139'),
(784, 140, '_student_photo', 'field_5acf9e173b70f'),
(785, 140, '_', 'field_5acf9e2f3b710'),
(786, 140, 'student_name', 'Student 10 Name'),
(787, 140, '_student_name', 'field_5acf9e98f8c6a'),
(788, 140, 'student_website', ''),
(789, 140, '_student_website', 'field_5acf9ea7f8c6b'),
(790, 140, 'project_1_title', 'Project 1 Student 10'),
(791, 140, '_project_1_title', 'field_5acfa7c0f2d80'),
(792, 140, 'project_1_collaborator', ''),
(793, 140, '_project_1_collaborator', 'field_5acfa7d1f2d81'),
(794, 140, 'project_1_description', ''),
(795, 140, '_project_1_description', 'field_5acfa7ddf2d82'),
(796, 140, 'project_1_image_1', '132'),
(797, 140, '_project_1_image_1', 'field_5acfa7e7f2d83'),
(798, 140, 'project_1_image_2', ''),
(799, 140, '_project_1_image_2', 'field_5acfa7faf2d84'),
(800, 140, 'project_1_image_3', ''),
(801, 140, '_project_1_image_3', 'field_5acfa805f2d85'),
(802, 140, 'student_twitter', ''),
(803, 140, '_student_twitter', 'field_5acfac89103c1'),
(804, 140, 'student_instagram', ''),
(805, 140, '_student_instagram', 'field_5acfaca1103c2'),
(806, 140, 'student_facebook', ''),
(807, 140, '_student_facebook', 'field_5acfacbf103c3'),
(808, 140, 'student_pinterest', ''),
(809, 140, '_student_pinterest', 'field_5acfacc8103c4'),
(810, 140, 'project_2_title', ''),
(811, 140, '_project_2_title', 'field_5acfaf63008de'),
(812, 140, 'project_2_description', ''),
(813, 140, '_project_2_description', 'field_5acfb061008e0'),
(814, 140, 'project_2_image_1', ''),
(815, 140, '_project_2_image_1', 'field_5acfb06c008e1'),
(816, 140, 'project_2_image_2', ''),
(817, 140, '_project_2_image_2', 'field_5acfb1d1008e2'),
(818, 140, 'project_2_image_3', ''),
(819, 140, '_project_2_image_3', 'field_5acfb1df008e3'),
(820, 140, 'project_3_title', ''),
(821, 140, '_project_3_title', 'field_5acfb1f2008e4'),
(822, 140, 'project_3_collaborator', ''),
(823, 140, '_project_3_collaborator', 'field_5acfb1fa008e5'),
(824, 140, 'project_3_description', ''),
(825, 140, '_project_3_description', 'field_5acfb202008e6'),
(826, 140, 'project_3_image_1', ''),
(827, 140, '_project_3_image_1', 'field_5acfb20d008e7'),
(828, 140, 'project_3_image_2', ''),
(829, 140, '_project_3_image_2', 'field_5acfb21a008e8'),
(830, 140, 'project_3_image_3', ''),
(831, 140, '_project_3_image_3', 'field_5acfb229008e9') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(832, 140, 'student_category_1', 'Advertising'),
(833, 140, '_student_category_1', 'field_5acfbb2aa9042'),
(834, 140, 'student_category_2', 'Branding'),
(835, 140, '_student_category_2', 'field_5acfbb47a9043'),
(836, 140, 'student_category_3', 'Packaging'),
(837, 140, '_student_category_3', 'field_5acfbb60a9044'),
(838, 140, '_yoast_wpseo_content_score', '30'),
(839, 141, '_wp_attached_file', '2018/05/p_logo.png'),
(840, 141, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:400;s:4:"file";s:18:"2018/05/p_logo.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"p_logo-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:18:"p_logo-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(841, 142, '_wp_attached_file', '2018/05/cropped-p_logo.png'),
(842, 142, '_wp_attachment_context', 'custom-header'),
(843, 142, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:26:"2018/05/cropped-p_logo.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"cropped-p_logo-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:26:"cropped-p_logo-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:26:"cropped-p_logo-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:17:"attachment_parent";i:141;}'),
(844, 142, '_wp_attachment_custom_header_last_used_portshowlio18', '1525379489'),
(845, 142, '_wp_attachment_is_custom_header', 'portshowlio18'),
(846, 143, '_wp_trash_meta_status', 'publish'),
(847, 143, '_wp_trash_meta_time', '1525379489'),
(848, 145, '_wp_attached_file', '2018/04/new.jpg'),
(849, 145, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:730;s:6:"height";i:546;s:4:"file";s:15:"2018/04/new.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"new-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:15:"new-300x224.jpg";s:5:"width";i:300;s:6:"height";i:224;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(850, 37, 'student_hover_photo', '145'),
(851, 37, '_student_hover_photo', 'field_5aeff0311f7c4'),
(852, 146, '_wp_attached_file', '2018/04/oso-perezoso.jpg'),
(853, 146, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:924;s:6:"height";i:530;s:4:"file";s:24:"2018/04/oso-perezoso.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"oso-perezoso-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"oso-perezoso-300x172.jpg";s:5:"width";i:300;s:6:"height";i:172;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"oso-perezoso-768x441.jpg";s:5:"width";i:768;s:6:"height";i:441;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(854, 77, 'student_hover_photo', '146'),
(855, 77, '_student_hover_photo', 'field_5aeff0311f7c4'),
(856, 140, 'student_hover_photo', '145'),
(857, 140, '_student_hover_photo', 'field_5aeff0311f7c4'),
(858, 136, 'student_hover_photo', '146'),
(859, 136, '_student_hover_photo', 'field_5aeff0311f7c4'),
(860, 99, 'student_hover_photo', '145'),
(861, 99, '_student_hover_photo', 'field_5aeff0311f7c4'),
(862, 98, 'student_hover_photo', '146'),
(863, 98, '_student_hover_photo', 'field_5aeff0311f7c4'),
(864, 97, 'student_hover_photo', '145'),
(865, 97, '_student_hover_photo', 'field_5aeff0311f7c4'),
(866, 96, 'student_hover_photo', '145'),
(867, 96, '_student_hover_photo', 'field_5aeff0311f7c4'),
(868, 95, 'student_hover_photo', '146'),
(869, 95, '_student_hover_photo', 'field_5aeff0311f7c4'),
(870, 78, 'student_hover_photo', '145'),
(871, 78, '_student_hover_photo', 'field_5aeff0311f7c4'),
(872, 77, 'focus', 'Illustration'),
(873, 77, '_focus', 'field_5af2826546f6c'),
(874, 140, 'focus', 'Art Direction'),
(875, 140, '_focus', 'field_5af2826546f6c'),
(876, 136, 'focus', 'Advertising'),
(877, 136, '_focus', 'field_5af2826546f6c'),
(878, 99, 'focus', 'Packaging'),
(879, 99, '_focus', 'field_5af2826546f6c'),
(880, 96, 'focus', 'Advertising'),
(881, 96, '_focus', 'field_5af2826546f6c'),
(882, 95, 'focus', 'Print Design'),
(883, 95, '_focus', 'field_5af2826546f6c'),
(884, 78, 'focus', 'Illustration'),
(885, 78, '_focus', 'field_5af2826546f6c'),
(886, 97, 'focus', 'Visual Design'),
(887, 97, '_focus', 'field_5af2826546f6c'),
(888, 98, 'focus', 'Default'),
(889, 98, '_focus', 'field_5af2826546f6c'),
(890, 148, '_edit_last', '1'),
(891, 148, '_wp_page_template', 'template-home.php'),
(892, 149, 'background_image', ''),
(893, 149, '_background_image', 'field_5ae759c32faae'),
(894, 149, 'logonav', ''),
(895, 149, '_logonav', 'field_5ae7683eabaca'),
(896, 148, 'background_image', ''),
(897, 148, '_background_image', 'field_5ae759c32faae'),
(898, 148, 'logonav', ''),
(899, 148, '_logonav', 'field_5ae7683eabaca'),
(900, 148, '_edit_lock', '1525972845:1') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-04-05 02:11:06', '2018-04-05 02:11:06', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2018-04-05 02:11:06', '2018-04-05 02:11:06', '', 0, 'http://2018.portshowl.io/?p=1', 0, 'post', '', 1),
(2, 1, '2018-04-05 02:11:06', '2018-04-05 02:11:06', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://2018.portshowl.io/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2018-04-05 02:11:06', '2018-04-05 02:11:06', '', 0, 'http://2018.portshowl.io/?page_id=2', 0, 'page', '', 0),
(14, 1, '2018-04-05 18:06:37', '2018-04-05 18:06:37', '<h1>Hello Portshowlio</h1>', 'home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-05-10 17:19:39', '2018-05-10 17:19:39', '', 0, 'http://2018.portshowl.io/?page_id=14', 0, 'page', '', 0),
(15, 1, '2018-04-05 18:06:37', '2018-04-05 18:06:37', '', 'home', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2018-04-05 18:06:37', '2018-04-05 18:06:37', '', 14, 'http://2018.portshowl.io/2018/04/05/14-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2018-04-05 18:17:13', '2018-04-05 18:17:13', '<h1>Hello Portshowlio</h1>', 'home', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2018-04-05 18:17:13', '2018-04-05 18:17:13', '', 14, 'http://2018.portshowl.io/2018/04/05/14-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2018-04-05 18:18:50', '2018-04-05 18:18:50', '', '01-arctic-fox-den.adapt.1900.1', '', 'inherit', 'open', 'closed', '', '01-arctic-fox-den-adapt-1900-1', '', '', '2018-04-26 18:46:30', '2018-04-26 18:46:30', '', 14, 'http://2018.portshowl.io/wp-content/uploads/2018/04/01-arctic-fox-den.adapt_.1900.1.jpg', 0, 'attachment', 'image/jpeg', 0),
(19, 1, '2018-04-12 03:27:47', '2018-04-12 03:27:47', '{"old_sidebars_widgets_data":{"value":{"wp_inactive_widgets":[],"sidebar-1":["search-2","recent-posts-2","recent-comments-2","archives-2","categories-2","meta-2"]},"type":"global_variable","user_id":1,"date_modified_gmt":"2018-04-12 03:27:47"}}', '', '', 'trash', 'closed', 'closed', '', '60ca60db-6fd1-4029-b97e-db0d31d67ed9', '', '', '2018-04-12 03:27:47', '2018-04-12 03:27:47', '', 0, 'http://2018.portshowl.io/2018/04/12/60ca60db-6fd1-4029-b97e-db0d31d67ed9/', 0, 'customize_changeset', '', 0),
(20, 1, '2018-04-12 03:40:44', '2018-04-12 03:40:44', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:14:"front-page.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Splash', 'splash', 'publish', 'closed', 'closed', '', 'group_5aced51f8a926', '', '', '2018-05-10 17:19:08', '2018-05-10 17:19:08', '', 0, 'http://2018.portshowl.io/?post_type=acf-field-group&#038;p=20', 0, 'acf-field-group', '', 0),
(21, 1, '2018-04-12 03:40:44', '2018-04-12 03:40:44', 'a:12:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:7:"wpautop";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'description', 'description', 'publish', 'closed', 'closed', '', 'field_5aced5291c62b', '', '', '2018-05-10 17:19:08', '2018-05-10 17:19:08', '', 20, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=21', 0, 'acf-field', '', 0),
(22, 1, '2018-04-12 03:43:15', '2018-04-12 03:43:15', '<h1>Hello Portshowlio</h1>', 'home', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2018-04-12 03:43:15', '2018-04-12 03:43:15', '', 14, 'http://2018.portshowl.io/2018/04/12/14-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2018-04-12 03:52:14', '2018-04-12 03:52:14', '<h1>Hello Portshowlio</h1>', 'home', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2018-04-12 03:52:14', '2018-04-12 03:52:14', '', 14, 'http://2018.portshowl.io/2018/04/12/14-revision-v1/', 0, 'revision', '', 0),
(24, 1, '2018-04-12 03:55:42', '2018-04-12 03:55:42', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Day 1 Title', 'day_1_title', 'publish', 'closed', 'closed', '', 'field_5aced850d76fa', '', '', '2018-05-10 17:19:08', '2018-05-10 17:19:08', '', 20, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=24', 1, 'acf-field', '', 0),
(25, 1, '2018-04-12 03:55:42', '2018-04-12 03:55:42', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Day 1 Date', 'day_1_date', 'publish', 'closed', 'closed', '', 'field_5aced85cd76fb', '', '', '2018-05-10 17:19:08', '2018-05-10 17:19:08', '', 20, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=25', 2, 'acf-field', '', 0),
(26, 1, '2018-04-12 03:55:42', '2018-04-12 03:55:42', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Day 1 Time', 'day_1_time', 'publish', 'closed', 'closed', '', 'field_5aced865d76fc', '', '', '2018-05-10 17:19:08', '2018-05-10 17:19:08', '', 20, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=26', 3, 'acf-field', '', 0),
(27, 1, '2018-04-12 03:55:42', '2018-04-12 03:55:42', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Day 2 Title', 'day_2_title', 'publish', 'closed', 'closed', '', 'field_5aced888d76fd', '', '', '2018-05-10 17:19:08', '2018-05-10 17:19:08', '', 20, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=27', 4, 'acf-field', '', 0),
(28, 1, '2018-04-12 03:55:42', '2018-04-12 03:55:42', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Day 2 Date', 'day_2_date', 'publish', 'closed', 'closed', '', 'field_5aced88ed76fe', '', '', '2018-05-10 17:19:08', '2018-05-10 17:19:08', '', 20, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=28', 5, 'acf-field', '', 0),
(29, 1, '2018-04-12 03:55:42', '2018-04-12 03:55:42', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Day 2 Time', 'day_2_time', 'publish', 'closed', 'closed', '', 'field_5aced894d76ff', '', '', '2018-05-10 17:19:08', '2018-05-10 17:19:08', '', 20, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=29', 6, 'acf-field', '', 0),
(30, 1, '2018-04-12 03:55:42', '2018-04-12 03:55:42', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Facebook Link', 'facebook_link', 'publish', 'closed', 'closed', '', 'field_5aced899d7700', '', '', '2018-05-10 17:19:08', '2018-05-10 17:19:08', '', 20, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=30', 7, 'acf-field', '', 0),
(31, 1, '2018-04-12 03:55:42', '2018-04-12 03:55:42', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Insta Link', 'insta_link', 'publish', 'closed', 'closed', '', 'field_5aced8a5d7701', '', '', '2018-05-10 17:19:08', '2018-05-10 17:19:08', '', 20, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=31', 8, 'acf-field', '', 0),
(32, 1, '2018-04-12 03:55:42', '2018-04-12 03:55:42', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Twitter Link', 'twitter_link', 'publish', 'closed', 'closed', '', 'field_5aced8b4d7702', '', '', '2018-05-10 17:19:08', '2018-05-10 17:19:08', '', 20, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=32', 9, 'acf-field', '', 0),
(33, 1, '2018-04-12 04:02:08', '2018-04-12 04:02:08', '<h1>Hello Portshowlio</h1>', 'home', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2018-04-12 04:02:08', '2018-04-12 04:02:08', '', 14, 'http://2018.portshowl.io/2018/04/12/14-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2018-04-12 04:04:55', '2018-04-12 04:04:55', '<h1>Hello Portshowlio</h1>', 'home', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2018-04-12 04:04:55', '2018-04-12 04:04:55', '', 14, 'http://2018.portshowl.io/2018/04/12/14-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2018-04-12 17:38:31', '2018-04-12 17:38:31', 'Here is a student page', 'Student 1', '', 'publish', 'closed', 'closed', '', 'student1', '', '', '2018-05-07 06:21:33', '2018-05-07 06:21:33', '', 0, 'http://2018.portshowl.io/?post_type=student&#038;p=37', 0, 'student', '', 0),
(38, 1, '2018-04-12 17:57:39', '2018-04-12 17:57:39', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:7:"student";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Student Page', 'student-page', 'publish', 'closed', 'closed', '', 'group_5acf9e0d9afcb', '', '', '2018-05-09 05:10:07', '2018-05-09 05:10:07', '', 0, 'http://2018.portshowl.io/?post_type=acf-field-group&#038;p=38', 0, 'acf-field-group', '', 0),
(39, 1, '2018-04-12 17:58:24', '2018-04-12 17:58:24', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'student photo', 'student_photo', 'publish', 'closed', 'closed', '', 'field_5acf9e173b70f', '', '', '2018-04-12 17:58:24', '2018-04-12 17:58:24', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&p=39', 0, 'acf-field', '', 0),
(40, 1, '2018-04-12 17:58:24', '2018-04-12 17:58:24', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', '', '', 'publish', 'closed', 'closed', '', 'field_5acf9e2f3b710', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=40', 2, 'acf-field', '', 0),
(41, 1, '2018-04-12 18:00:59', '2018-04-12 18:00:59', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'student name', 'student_name', 'publish', 'closed', 'closed', '', 'field_5acf9e98f8c6a', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=41', 3, 'acf-field', '', 0),
(42, 1, '2018-04-12 18:00:59', '2018-04-12 18:00:59', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'student website', 'student_website', 'publish', 'closed', 'closed', '', 'field_5acf9ea7f8c6b', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=42', 4, 'acf-field', '', 0),
(43, 1, '2018-04-12 18:01:33', '2018-04-12 18:01:33', '', 'kangoroo', '', 'inherit', 'open', 'closed', '', 'kangoroo', '', '', '2018-04-26 19:15:16', '2018-04-26 19:15:16', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/kangoroo.jpg', 0, 'attachment', 'image/jpeg', 0),
(44, 1, '2018-04-12 18:01:58', '2018-04-12 18:01:58', '', 'memay2016', '', 'inherit', 'open', 'closed', '', 'memay2016', '', '', '2018-04-12 18:01:58', '2018-04-12 18:01:58', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/memay2016.jpg', 0, 'attachment', 'image/jpeg', 0),
(45, 1, '2018-04-12 18:02:14', '2018-04-12 18:02:14', '', 'memay2016', '', 'inherit', 'open', 'closed', '', 'memay2016-2', '', '', '2018-04-12 18:08:21', '2018-04-12 18:08:21', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/memay2016-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(46, 1, '2018-04-12 18:02:26', '2018-04-12 18:02:26', '', 'cats3', '', 'inherit', 'open', 'closed', '', 'cats3', '', '', '2018-04-12 19:24:16', '2018-04-12 19:24:16', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/cats3.jpg', 0, 'attachment', 'image/jpeg', 0),
(47, 1, '2018-04-12 18:40:22', '2018-04-12 18:40:22', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'project 1 title', 'project_1_title', 'publish', 'closed', 'closed', '', 'field_5acfa7c0f2d80', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=47', 5, 'acf-field', '', 0),
(48, 1, '2018-04-12 18:40:22', '2018-04-12 18:40:22', 'a:12:{s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:0:{}s:8:"taxonomy";a:0:{}s:7:"filters";a:1:{i:0;s:9:"post_type";}s:8:"elements";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:13:"return_format";s:2:"id";}', 'project 1 collaborator', 'project_1_collaborator', 'publish', 'closed', 'closed', '', 'field_5acfa7d1f2d81', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=48', 6, 'acf-field', '', 0),
(49, 1, '2018-04-12 18:40:22', '2018-04-12 18:40:22', 'a:12:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:7:"wpautop";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'project 1 description', 'project_1_description', 'publish', 'closed', 'closed', '', 'field_5acfa7ddf2d82', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=49', 7, 'acf-field', '', 0),
(50, 1, '2018-04-12 18:40:22', '2018-04-12 18:40:22', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'project 1 image 1', 'project_1_image_1', 'publish', 'closed', 'closed', '', 'field_5acfa7e7f2d83', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=50', 8, 'acf-field', '', 0),
(51, 1, '2018-04-12 18:40:22', '2018-04-12 18:40:22', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'project 1 image 2', 'project_1_image_2', 'publish', 'closed', 'closed', '', 'field_5acfa7faf2d84', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=51', 9, 'acf-field', '', 0),
(52, 1, '2018-04-12 18:40:22', '2018-04-12 18:40:22', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'project 1 image 3', 'project_1_image_3', 'publish', 'closed', 'closed', '', 'field_5acfa805f2d85', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=52', 10, 'acf-field', '', 0),
(53, 1, '2018-04-12 19:00:43', '2018-04-12 19:00:43', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'student twitter', 'student_twitter', 'publish', 'closed', 'closed', '', 'field_5acfac89103c1', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=53', 11, 'acf-field', '', 0),
(54, 1, '2018-04-12 19:00:43', '2018-04-12 19:00:43', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'student instagram', 'student_instagram', 'publish', 'closed', 'closed', '', 'field_5acfaca1103c2', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=54', 12, 'acf-field', '', 0),
(55, 1, '2018-04-12 19:00:43', '2018-04-12 19:00:43', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'student facebook', 'student_facebook', 'publish', 'closed', 'closed', '', 'field_5acfacbf103c3', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=55', 13, 'acf-field', '', 0),
(56, 1, '2018-04-12 19:00:43', '2018-04-12 19:00:43', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'student pinterest', 'student_pinterest', 'publish', 'closed', 'closed', '', 'field_5acfacc8103c4', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=56', 14, 'acf-field', '', 0),
(57, 1, '2018-04-12 19:23:37', '2018-04-12 19:23:37', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Project 2 Title', 'project_2_title', 'publish', 'closed', 'closed', '', 'field_5acfaf63008de', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=57', 15, 'acf-field', '', 0),
(58, 1, '2018-04-12 19:23:37', '2018-04-12 19:23:37', 'a:14:{s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:0:{}s:13:"default_value";a:0:{}s:10:"allow_null";i:0;s:8:"multiple";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:11:"placeholder";s:0:"";s:8:"disabled";i:0;s:8:"readonly";i:0;}', 'Project 2 collaborator', 'project_2_collaborator', 'publish', 'closed', 'closed', '', 'field_5acfaf6e008df', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=58', 16, 'acf-field', '', 0),
(59, 1, '2018-04-12 19:23:37', '2018-04-12 19:23:37', 'a:12:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:7:"wpautop";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'project 2 description', 'project_2_description', 'publish', 'closed', 'closed', '', 'field_5acfb061008e0', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=59', 17, 'acf-field', '', 0),
(60, 1, '2018-04-12 19:23:37', '2018-04-12 19:23:37', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'project 2 image 1', 'project_2_image_1', 'publish', 'closed', 'closed', '', 'field_5acfb06c008e1', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=60', 18, 'acf-field', '', 0),
(61, 1, '2018-04-12 19:23:37', '2018-04-12 19:23:37', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'project 2 image 2', 'project_2_image_2', 'publish', 'closed', 'closed', '', 'field_5acfb1d1008e2', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=61', 19, 'acf-field', '', 0),
(62, 1, '2018-04-12 19:23:37', '2018-04-12 19:23:37', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'project 2 image 3', 'project_2_image_3', 'publish', 'closed', 'closed', '', 'field_5acfb1df008e3', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=62', 20, 'acf-field', '', 0),
(63, 1, '2018-04-12 19:23:37', '2018-04-12 19:23:37', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'project 3 title', 'project_3_title', 'publish', 'closed', 'closed', '', 'field_5acfb1f2008e4', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=63', 21, 'acf-field', '', 0),
(64, 1, '2018-04-12 19:23:37', '2018-04-12 19:23:37', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'project 3 collaborator', 'project_3_collaborator', 'publish', 'closed', 'closed', '', 'field_5acfb1fa008e5', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=64', 22, 'acf-field', '', 0),
(65, 1, '2018-04-12 19:23:37', '2018-04-12 19:23:37', 'a:12:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:7:"wpautop";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'project 3 description', 'project_3_description', 'publish', 'closed', 'closed', '', 'field_5acfb202008e6', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=65', 23, 'acf-field', '', 0),
(66, 1, '2018-04-12 19:23:37', '2018-04-12 19:23:37', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'project 3 image 1', 'project_3_image_1', 'publish', 'closed', 'closed', '', 'field_5acfb20d008e7', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=66', 24, 'acf-field', '', 0),
(67, 1, '2018-04-12 19:23:37', '2018-04-12 19:23:37', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'project 3 image 2', 'project_3_image_2', 'publish', 'closed', 'closed', '', 'field_5acfb21a008e8', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=67', 25, 'acf-field', '', 0),
(68, 1, '2018-04-12 19:23:37', '2018-04-12 19:23:37', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'project 3 image 3', 'project_3_image_3', 'publish', 'closed', 'closed', '', 'field_5acfb229008e9', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=68', 26, 'acf-field', '', 0),
(69, 1, '2018-04-12 20:03:00', '2018-04-12 20:03:00', 'a:14:{s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:15:{s:7:"Default";s:7:"Default";s:11:"Advertising";s:11:"Advertising";s:13:"Art Direction";s:13:"Art Direction";s:8:"Branding";s:8:"Branding";s:12:"Illustration";s:12:"Illustration";s:11:"Game Design";s:11:"Game Design";s:6:"Layout";s:6:"Layout";s:15:"Motion Graphics";s:15:"Motion Graphics";s:9:"Packaging";s:9:"Packaging";s:12:"Print Design";s:12:"Print Design";s:10:"Typography";s:10:"Typography";s:7:"UX / UI";s:7:"UX / UI";s:10:"Web Design";s:10:"Web Design";s:15:"Virtual Reality";s:15:"Virtual Reality";s:13:"Visual Design";s:13:"Visual Design";}s:13:"default_value";a:1:{i:0;s:10:"choose one";}s:10:"allow_null";i:0;s:8:"multiple";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:11:"placeholder";s:0:"";s:8:"disabled";i:0;s:8:"readonly";i:0;}', 'student category 1', 'student_category_1', 'publish', 'closed', 'closed', '', 'field_5acfbb2aa9042', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=69', 27, 'acf-field', '', 0),
(70, 1, '2018-04-12 20:03:00', '2018-04-12 20:03:00', 'a:14:{s:4:"type";s:6:"select";s:12:"instructions";s:20:"choose your category";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:14:{s:11:"Advertising";s:11:"Advertising";s:13:"Art Direction";s:13:"Art Direction";s:8:"Branding";s:8:"Branding";s:12:"Illustration";s:12:"Illustration";s:11:"Game Design";s:11:"Game Design";s:6:"Layout";s:6:"Layout";s:15:"Motion Graphics";s:15:"Motion Graphics";s:9:"Packaging";s:9:"Packaging";s:12:"Print Design";s:12:"Print Design";s:10:"Typography";s:10:"Typography";s:7:"UX / UI";s:7:"UX / UI";s:10:"Web Design";s:10:"Web Design";s:15:"Virtual Reality";s:15:"Virtual Reality";s:13:"Visual Design";s:13:"Visual Design";}s:13:"default_value";a:1:{i:0;s:10:"select one";}s:10:"allow_null";i:0;s:8:"multiple";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:11:"placeholder";s:0:"";s:8:"disabled";i:0;s:8:"readonly";i:0;}', 'student category 2', 'student_category_2', 'publish', 'closed', 'closed', '', 'field_5acfbb47a9043', '', '', '2018-05-09 05:10:07', '2018-05-09 05:10:07', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=70', 29, 'acf-field', '', 0),
(71, 1, '2018-04-12 20:03:00', '2018-04-12 20:03:00', 'a:14:{s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:14:{s:11:"Advertising";s:11:"Advertising";s:13:"Art Direction";s:13:"Art Direction";s:8:"Branding";s:8:"Branding";s:12:"Illustration";s:12:"Illustration";s:11:"Game Design";s:11:"Game Design";s:6:"Layout";s:6:"Layout";s:15:"Motion Graphics";s:15:"Motion Graphics";s:9:"Packaging";s:9:"Packaging";s:12:"Print Design";s:12:"Print Design";s:10:"Typography";s:10:"Typography";s:7:"UX / UI";s:7:"UX / UI";s:10:"Web Design";s:10:"Web Design";s:15:"Virtual Reality";s:15:"Virtual Reality";s:13:"Visual Design";s:13:"Visual Design";}s:13:"default_value";a:1:{i:0;s:10:"select one";}s:10:"allow_null";i:0;s:8:"multiple";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:11:"placeholder";s:0:"";s:8:"disabled";i:0;s:8:"readonly";i:0;}', 'student category 3', 'student_category_3', 'publish', 'closed', 'closed', '', 'field_5acfbb60a9044', '', '', '2018-05-09 05:10:07', '2018-05-09 05:10:07', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&#038;p=71', 30, 'acf-field', '', 0),
(73, 1, '2018-04-17 23:37:37', '2018-04-17 23:37:37', '<h1>Hello Portshowlio</h1>', 'home', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2018-04-17 23:37:37', '2018-04-17 23:37:37', '', 14, 'http://2018.portshowl.io/2018/04/17/14-revision-v1/', 0, 'revision', '', 0),
(74, 1, '2018-04-18 03:42:11', '2018-04-18 03:42:11', '', 'logo_placeholder', '', 'inherit', 'open', 'closed', '', 'logo_placeholder', '', '', '2018-04-18 03:42:11', '2018-04-18 03:42:11', '', 0, 'http://2018.portshowl.io/wp-content/uploads/2018/04/logo_placeholder.svg', 0, 'attachment', 'image/svg+xml', 0),
(77, 1, '2018-04-26 18:46:41', '2018-04-26 18:46:41', '', 'Student 2', '', 'publish', 'closed', 'closed', '', 'student-2', '', '', '2018-05-09 16:17:38', '2018-05-09 16:17:38', '', 0, 'http://2018.portshowl.io/?post_type=student&#038;p=77', 0, 'student', '', 0),
(78, 1, '2018-04-26 18:51:39', '2018-04-26 18:51:39', '', 'Student 3', '', 'publish', 'closed', 'closed', '', 'student-3', '', '', '2018-05-09 16:20:31', '2018-05-09 16:20:31', '', 0, 'http://2018.portshowl.io/?post_type=student&#038;p=78', 0, 'student', '', 0),
(79, 1, '2018-04-26 18:50:26', '2018-04-26 18:50:26', '', 'PICT0003', '', 'inherit', 'open', 'closed', '', 'pict0003', '', '', '2018-04-26 18:50:26', '2018-04-26 18:50:26', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/PICT0003.jpg', 0, 'attachment', 'image/jpeg', 0),
(80, 1, '2018-04-26 18:50:28', '2018-04-26 18:50:28', '', 'PICT0017', '', 'inherit', 'open', 'closed', '', 'pict0017', '', '', '2018-04-26 18:51:34', '2018-04-26 18:51:34', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/PICT0017.jpg', 0, 'attachment', 'image/jpeg', 0),
(81, 1, '2018-04-26 18:50:30', '2018-04-26 18:50:30', '', 'PICT0047', '', 'inherit', 'open', 'closed', '', 'pict0047', '', '', '2018-04-26 18:50:30', '2018-04-26 18:50:30', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/PICT0047.jpg', 0, 'attachment', 'image/jpeg', 0),
(82, 1, '2018-04-26 18:50:31', '2018-04-26 18:50:31', '', 'PICT0055', '', 'inherit', 'open', 'closed', '', 'pict0055', '', '', '2018-04-26 18:50:31', '2018-04-26 18:50:31', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/PICT0055.jpg', 0, 'attachment', 'image/jpeg', 0),
(83, 1, '2018-04-26 18:50:33', '2018-04-26 18:50:33', '', 'PICT0056', '', 'inherit', 'open', 'closed', '', 'pict0056', '', '', '2018-04-26 18:50:33', '2018-04-26 18:50:33', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/PICT0056.jpg', 0, 'attachment', 'image/jpeg', 0),
(84, 1, '2018-04-26 18:50:35', '2018-04-26 18:50:35', '', 'PICT0057', '', 'inherit', 'open', 'closed', '', 'pict0057', '', '', '2018-04-26 18:50:35', '2018-04-26 18:50:35', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/PICT0057.jpg', 0, 'attachment', 'image/jpeg', 0),
(85, 1, '2018-04-26 18:50:36', '2018-04-26 18:50:36', '', 'PICT0061', '', 'inherit', 'open', 'closed', '', 'pict0061', '', '', '2018-04-26 18:50:36', '2018-04-26 18:50:36', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/PICT0061.jpg', 0, 'attachment', 'image/jpeg', 0),
(86, 1, '2018-04-26 18:54:46', '2018-04-26 18:54:46', '', 'cute-animals-5-animals-9403312-650-456', '', 'inherit', 'open', 'closed', '', 'cute-animals-5-animals-9403312-650-456', '', '', '2018-05-03 20:04:36', '2018-05-03 20:04:36', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/cute-animals-5-animals-9403312-650-456.jpg', 0, 'attachment', 'image/jpeg', 0),
(87, 1, '2018-04-26 18:54:47', '2018-04-26 18:54:47', '', 'cute-animals-hokkaido-ezo-japan-5', '', 'inherit', 'open', 'closed', '', 'cute-animals-hokkaido-ezo-japan-5', '', '', '2018-05-03 20:00:52', '2018-05-03 20:00:52', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/cute-animals-hokkaido-ezo-japan-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(88, 1, '2018-04-26 18:54:48', '2018-04-26 18:54:48', '', 'Cute-Animals3', '', 'inherit', 'open', 'closed', '', 'cute-animals3', '', '', '2018-05-03 19:58:11', '2018-05-03 19:58:11', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/Cute-Animals3.jpg', 0, 'attachment', 'image/jpeg', 0),
(89, 1, '2018-04-26 18:54:48', '2018-04-26 18:54:48', '', 'lots-of-cute-animals-5-1', '', 'inherit', 'open', 'closed', '', 'lots-of-cute-animals-5-1', '', '', '2018-04-26 19:53:23', '2018-04-26 19:53:23', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/lots-of-cute-animals-5-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(90, 1, '2018-04-26 18:54:49', '2018-04-26 18:54:49', '', 'Top-20-Worlds-Cutest-Animals', '', 'inherit', 'open', 'closed', '', 'top-20-worlds-cutest-animals', '', '', '2018-05-03 20:03:26', '2018-05-03 20:03:26', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/Top-20-Worlds-Cutest-Animals.jpg', 0, 'attachment', 'image/jpeg', 0),
(91, 1, '2018-04-26 18:54:49', '2018-04-26 18:54:49', '', 'MZ-7AaQh_400x400', '', 'inherit', 'open', 'closed', '', 'mz-7aaqh_400x400', '', '', '2018-05-03 20:04:06', '2018-05-03 20:04:06', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/MZ-7AaQh_400x400.jpg', 0, 'attachment', 'image/jpeg', 0),
(92, 1, '2018-04-26 18:54:50', '2018-04-26 18:54:50', '', 'enhanced-5913-1415212088-2', '', 'inherit', 'open', 'closed', '', 'enhanced-5913-1415212088-2', '', '', '2018-05-03 20:02:34', '2018-05-03 20:02:34', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/enhanced-5913-1415212088-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(93, 1, '2018-04-26 18:54:50', '2018-04-26 18:54:50', '', 'cute-baby-animals-13', '', 'inherit', 'open', 'closed', '', 'cute-baby-animals-13', '', '', '2018-04-26 18:54:50', '2018-04-26 18:54:50', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/cute-baby-animals-13.jpg', 0, 'attachment', 'image/jpeg', 0),
(94, 1, '2018-04-26 18:54:51', '2018-04-26 18:54:51', '', 'cute-baby-animals-10', '', 'inherit', 'open', 'closed', '', 'cute-baby-animals-10', '', '', '2018-05-03 19:59:13', '2018-05-03 19:59:13', '', 78, 'http://2018.portshowl.io/wp-content/uploads/2018/04/cute-baby-animals-10.jpg', 0, 'attachment', 'image/jpeg', 0),
(95, 1, '2018-04-26 18:55:22', '2018-04-26 18:55:22', '', 'Student 4', '', 'publish', 'closed', 'closed', '', 'student-4', '', '', '2018-05-09 16:21:12', '2018-05-09 16:21:12', '', 0, 'http://2018.portshowl.io/?post_type=student&#038;p=95', 0, 'student', '', 0),
(96, 1, '2018-04-26 18:56:31', '2018-04-26 18:56:31', '', 'Student 5', '', 'publish', 'closed', 'closed', '', 'student-5', '', '', '2018-05-09 16:19:06', '2018-05-09 16:19:06', '', 0, 'http://2018.portshowl.io/?post_type=student&#038;p=96', 0, 'student', '', 0),
(97, 1, '2018-04-26 18:57:13', '2018-04-26 18:57:13', '', 'Student 6', '', 'publish', 'closed', 'closed', '', 'student-6', '', '', '2018-05-09 16:21:39', '2018-05-09 16:21:39', '', 0, 'http://2018.portshowl.io/?post_type=student&#038;p=97', 0, 'student', '', 0),
(98, 1, '2018-04-26 19:15:42', '2018-04-26 19:15:42', '', 'Student 7', '', 'publish', 'closed', 'closed', '', 'student-7', '', '', '2018-05-09 16:22:00', '2018-05-09 16:22:00', '', 0, 'http://2018.portshowl.io/?post_type=student&#038;p=98', 0, 'student', '', 0),
(99, 1, '2018-04-26 19:53:27', '2018-04-26 19:53:27', '', 'Student 8', '', 'publish', 'closed', 'closed', '', 'student-8', '', '', '2018-05-09 16:22:17', '2018-05-09 16:22:17', '', 0, 'http://2018.portshowl.io/?post_type=student&#038;p=99', 0, 'student', '', 0),
(100, 1, '2018-04-26 20:46:30', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-04-26 20:46:30', '0000-00-00 00:00:00', '', 0, 'http://2018.portshowl.io/?p=100', 1, 'nav_menu_item', '', 0),
(101, 1, '2018-04-26 20:46:30', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-04-26 20:46:30', '0000-00-00 00:00:00', '', 0, 'http://2018.portshowl.io/?p=101', 1, 'nav_menu_item', '', 0),
(102, 1, '2018-04-26 20:46:30', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-04-26 20:46:30', '0000-00-00 00:00:00', '', 0, 'http://2018.portshowl.io/?p=102', 1, 'nav_menu_item', '', 0),
(103, 1, '2018-04-30 18:01:07', '2018-04-30 18:01:07', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:17:"template-home.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Home Page', 'home-page', 'publish', 'closed', 'closed', '', 'group_5ae759bc9189a', '', '', '2018-04-30 19:02:37', '2018-04-30 19:02:37', '', 0, 'http://2018.portshowl.io/?post_type=acf-field-group&#038;p=103', 0, 'acf-field-group', '', 0),
(104, 1, '2018-04-30 18:01:07', '2018-04-30 18:01:07', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'background image', 'background_image', 'publish', 'closed', 'closed', '', 'field_5ae759c32faae', '', '', '2018-04-30 18:01:07', '2018-04-30 18:01:07', '', 103, 'http://2018.portshowl.io/?post_type=acf-field&p=104', 0, 'acf-field', '', 0),
(105, 1, '2018-04-30 18:02:14', '2018-04-30 18:02:14', '', 'Zig-Zag', '', 'inherit', 'open', 'closed', '', 'zig-zag', '', '', '2018-04-30 18:02:14', '2018-04-30 18:02:14', '', 14, 'http://2018.portshowl.io/wp-content/uploads/2018/04/Zig-Zag.svg', 0, 'attachment', 'image/svg+xml', 0),
(106, 1, '2018-04-30 18:04:16', '2018-04-30 18:04:16', '', 'logopage', '', 'inherit', 'open', 'closed', '', 'logopage', '', '', '2018-04-30 18:04:38', '2018-04-30 18:04:38', '', 14, 'http://2018.portshowl.io/wp-content/uploads/2018/04/logopage.jpg', 0, 'attachment', 'image/jpeg', 0),
(107, 1, '2018-04-30 18:04:41', '2018-04-30 18:04:41', '<h1>Hello Portshowlio</h1>', 'home', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2018-04-30 18:04:41', '2018-04-30 18:04:41', '', 14, 'http://2018.portshowl.io/2018/04/30/14-revision-v1/', 0, 'revision', '', 0),
(108, 1, '2018-04-30 19:02:37', '2018-04-30 19:02:37', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'logonav', 'logonav', 'publish', 'closed', 'closed', '', 'field_5ae7683eabaca', '', '', '2018-04-30 19:02:37', '2018-04-30 19:02:37', '', 103, 'http://2018.portshowl.io/?post_type=acf-field&p=108', 1, 'acf-field', '', 0),
(109, 1, '2018-04-30 19:02:50', '2018-04-30 19:02:50', '<h1>Hello Portshowlio</h1>', 'home', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2018-04-30 19:02:50', '2018-04-30 19:02:50', '', 14, 'http://2018.portshowl.io/2018/04/30/14-revision-v1/', 0, 'revision', '', 0),
(110, 1, '2018-04-30 19:17:46', '2018-04-30 19:17:46', '', 'Zig-Zag', '', 'inherit', 'open', 'closed', '', 'zig-zag-2', '', '', '2018-04-30 19:17:46', '2018-04-30 19:17:46', '', 14, 'http://2018.portshowl.io/wp-content/uploads/2018/04/Zig-Zag-1.svg', 0, 'attachment', 'image/svg+xml', 0),
(111, 1, '2018-04-30 19:18:14', '2018-04-30 19:18:14', '', 'Zig-Zag', '', 'inherit', 'open', 'closed', '', 'zig-zag-3', '', '', '2018-04-30 19:18:14', '2018-04-30 19:18:14', '', 14, 'http://2018.portshowl.io/wp-content/uploads/2018/04/Zig-Zag-2.svg', 0, 'attachment', 'image/svg+xml', 0),
(112, 1, '2018-04-30 19:18:39', '2018-04-30 19:18:39', '', 'Dots', '', 'inherit', 'open', 'closed', '', 'dots', '', '', '2018-04-30 19:18:39', '2018-04-30 19:18:39', '', 14, 'http://2018.portshowl.io/wp-content/uploads/2018/04/Dots.svg', 0, 'attachment', 'image/svg+xml', 0),
(113, 1, '2018-04-30 19:19:07', '2018-04-30 19:19:07', '', 'Cheetos', '', 'inherit', 'open', 'closed', '', 'cheetos', '', '', '2018-04-30 19:19:07', '2018-04-30 19:19:07', '', 14, 'http://2018.portshowl.io/wp-content/uploads/2018/04/Cheetos.svg', 0, 'attachment', 'image/svg+xml', 0),
(114, 1, '2018-04-30 19:20:33', '2018-04-30 19:20:33', '', 'logonav_blackzz', '', 'inherit', 'open', 'closed', '', 'logonav_blackzz', '', '', '2018-04-30 19:20:33', '2018-04-30 19:20:33', '', 14, 'http://2018.portshowl.io/wp-content/uploads/2018/04/logonav_blackzz.svg', 0, 'attachment', 'image/svg+xml', 0),
(115, 1, '2018-04-30 19:20:53', '2018-04-30 19:20:53', '<h1>Hello Portshowlio</h1>', 'home', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2018-04-30 19:20:53', '2018-04-30 19:20:53', '', 14, 'http://2018.portshowl.io/2018/04/30/14-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2018-05-02 06:23:37', '2018-05-02 06:23:37', '', 'logonav_blackzz', '', 'inherit', 'open', 'closed', '', 'logonav_blackzz-2', '', '', '2018-05-02 06:23:37', '2018-05-02 06:23:37', '', 0, 'http://2018.portshowl.io/wp-content/uploads/2018/05/logonav_blackzz.png', 0, 'attachment', 'image/png', 0),
(117, 1, '2018-05-02 06:23:44', '2018-05-02 06:23:44', '', 'cropped-logonav_blackzz.png', '', 'inherit', 'open', 'closed', '', 'cropped-logonav_blackzz-png', '', '', '2018-05-02 06:23:44', '2018-05-02 06:23:44', '', 0, 'http://2018.portshowl.io/wp-content/uploads/2018/05/cropped-logonav_blackzz.png', 0, 'attachment', 'image/png', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(118, 1, '2018-05-02 06:23:48', '2018-05-02 06:23:48', '{"portshowlio18::header_image":{"value":"http:\\/\\/2018.portshowl.io\\/wp-content\\/uploads\\/2018\\/05\\/cropped-logonav_blackzz.png","type":"theme_mod","user_id":1,"date_modified_gmt":"2018-05-02 06:23:48"},"portshowlio18::header_image_data":{"value":{"url":"http:\\/\\/2018.portshowl.io\\/wp-content\\/uploads\\/2018\\/05\\/cropped-logonav_blackzz.png","thumbnail_url":"http:\\/\\/2018.portshowl.io\\/wp-content\\/uploads\\/2018\\/05\\/cropped-logonav_blackzz.png","timestamp":1525242225118,"attachment_id":117,"width":1000,"height":878},"type":"theme_mod","user_id":1,"date_modified_gmt":"2018-05-02 06:23:48"}}', '', '', 'trash', 'closed', 'closed', '', 'f2695f16-0340-4b0c-a9d2-50a3308205f6', '', '', '2018-05-02 06:23:48', '2018-05-02 06:23:48', '', 0, 'http://2018.portshowl.io/2018/05/02/f2695f16-0340-4b0c-a9d2-50a3308205f6/', 0, 'customize_changeset', '', 0),
(119, 1, '2018-05-03 19:58:31', '2018-05-03 19:58:31', '', 'moog', '', 'inherit', 'open', 'closed', '', 'moog', '', '', '2018-05-03 19:58:31', '2018-05-03 19:58:31', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/moog.svg', 0, 'attachment', 'image/svg+xml', 0),
(120, 1, '2018-05-03 19:58:31', '2018-05-03 19:58:31', '', 'stopbutton', '', 'inherit', 'open', 'closed', '', 'stopbutton', '', '', '2018-05-03 19:58:31', '2018-05-03 19:58:31', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/stopbutton.svg', 0, 'attachment', 'image/svg+xml', 0),
(121, 1, '2018-05-03 19:58:32', '2018-05-03 19:58:32', '', 'playbutton', '', 'inherit', 'open', 'closed', '', 'playbutton', '', '', '2018-05-03 19:58:32', '2018-05-03 19:58:32', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/playbutton.svg', 0, 'attachment', 'image/svg+xml', 0),
(122, 1, '2018-05-03 19:58:32', '2018-05-03 19:58:32', '', '808', '', 'inherit', 'open', 'closed', '', '808', '', '', '2018-05-03 19:58:32', '2018-05-03 19:58:32', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/808.svg', 0, 'attachment', 'image/svg+xml', 0),
(123, 1, '2018-05-03 19:58:33', '2018-05-03 19:58:33', '', '909', '', 'inherit', 'open', 'closed', '', '909', '', '', '2018-05-03 19:58:33', '2018-05-03 19:58:33', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/909.svg', 0, 'attachment', 'image/svg+xml', 0),
(124, 1, '2018-05-03 19:58:33', '2018-05-03 19:58:33', '', '303', '', 'inherit', 'open', 'closed', '', '303', '', '', '2018-05-03 19:58:33', '2018-05-03 19:58:33', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/303.svg', 0, 'attachment', 'image/svg+xml', 0),
(125, 1, '2018-05-03 19:58:34', '2018-05-03 19:58:34', '', 'buchla', '', 'inherit', 'open', 'closed', '', 'buchla', '', '', '2018-05-03 19:58:34', '2018-05-03 19:58:34', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/buchla.svg', 0, 'attachment', 'image/svg+xml', 0),
(126, 1, '2018-05-03 19:58:34', '2018-05-03 19:58:34', '', 'minimoog', '', 'inherit', 'open', 'closed', '', 'minimoog', '', '', '2018-05-03 19:58:34', '2018-05-03 19:58:34', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/minimoog.svg', 0, 'attachment', 'image/svg+xml', 0),
(127, 1, '2018-05-03 19:58:35', '2018-05-03 19:58:35', '', 'maq', '', 'inherit', 'open', 'closed', '', 'maq', '', '', '2018-05-03 19:58:35', '2018-05-03 19:58:35', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/maq.svg', 0, 'attachment', 'image/svg+xml', 0),
(128, 1, '2018-05-03 19:58:35', '2018-05-03 19:58:35', '', 'micro', '', 'inherit', 'open', 'closed', '', 'micro', '', '', '2018-05-03 19:58:35', '2018-05-03 19:58:35', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/micro.svg', 0, 'attachment', 'image/svg+xml', 0),
(129, 1, '2018-05-03 19:58:35', '2018-05-03 19:58:35', '', 'dx7', '', 'inherit', 'open', 'closed', '', 'dx7', '', '', '2018-05-03 19:58:35', '2018-05-03 19:58:35', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/dx7.svg', 0, 'attachment', 'image/svg+xml', 0),
(130, 1, '2018-05-03 19:58:36', '2018-05-03 19:58:36', '', 'fairlight', '', 'inherit', 'open', 'closed', '', 'fairlight', '', '', '2018-05-03 19:58:36', '2018-05-03 19:58:36', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/fairlight.svg', 0, 'attachment', 'image/svg+xml', 0),
(131, 1, '2018-05-03 19:58:36', '2018-05-03 19:58:36', '', 'hammond', '', 'inherit', 'open', 'closed', '', 'hammond', '', '', '2018-05-03 19:58:36', '2018-05-03 19:58:36', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/hammond.svg', 0, 'attachment', 'image/svg+xml', 0),
(132, 1, '2018-05-03 19:58:37', '2018-05-03 19:58:37', '', 'doepfera100', '', 'inherit', 'open', 'closed', '', 'doepfera100', '', '', '2018-05-03 19:58:37', '2018-05-03 19:58:37', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/doepfera100.svg', 0, 'attachment', 'image/svg+xml', 0),
(133, 1, '2018-05-03 19:58:37', '2018-05-03 19:58:37', '', 'theremin', '', 'inherit', 'open', 'closed', '', 'theremin', '', '', '2018-05-03 19:58:37', '2018-05-03 19:58:37', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/theremin.svg', 0, 'attachment', 'image/svg+xml', 0),
(134, 1, '2018-05-03 19:58:38', '2018-05-03 19:58:38', '', 'magnetophone', '', 'inherit', 'open', 'closed', '', 'magnetophone', '', '', '2018-05-03 19:58:38', '2018-05-03 19:58:38', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/magnetophone.svg', 0, 'attachment', 'image/svg+xml', 0),
(135, 1, '2018-05-03 19:58:38', '2018-05-03 19:58:38', '', 'tr-909', '', 'inherit', 'open', 'closed', '', 'tr-909', '', '', '2018-05-03 19:58:38', '2018-05-03 19:58:38', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/tr-909.svg', 0, 'attachment', 'image/svg+xml', 0),
(136, 1, '2018-05-03 20:07:24', '2018-05-03 20:07:24', '', 'Student 9', '', 'publish', 'closed', 'closed', '', 'student-9', '', '', '2018-05-09 16:18:24', '2018-05-09 16:18:24', '', 0, 'http://2018.portshowl.io/?post_type=student&#038;p=136', 0, 'student', '', 0),
(137, 1, '2018-05-03 20:06:55', '2018-05-03 20:06:55', '', '01-arctic-fox-den.adapt.1900.1', '', 'inherit', 'open', 'closed', '', '01-arctic-fox-den-adapt-1900-1-2', '', '', '2018-05-03 20:06:55', '2018-05-03 20:06:55', '', 136, 'http://2018.portshowl.io/wp-content/uploads/2018/05/01-arctic-fox-den.adapt_.1900.1.jpg', 0, 'attachment', 'image/jpeg', 0),
(138, 1, '2018-05-03 20:06:56', '2018-05-03 20:06:56', '', 'cute-baby-animals-13', '', 'inherit', 'open', 'closed', '', 'cute-baby-animals-13-2', '', '', '2018-05-03 20:06:59', '2018-05-03 20:06:59', '', 136, 'http://2018.portshowl.io/wp-content/uploads/2018/05/cute-baby-animals-13.jpg', 0, 'attachment', 'image/jpeg', 0),
(139, 1, '2018-05-03 20:06:57', '2018-05-03 20:06:57', '', 'fox-1540833_1920', '', 'inherit', 'open', 'closed', '', 'fox-1540833_1920', '', '', '2018-05-03 20:07:37', '2018-05-03 20:07:37', '', 136, 'http://2018.portshowl.io/wp-content/uploads/2018/05/fox-1540833_1920.jpg', 0, 'attachment', 'image/jpeg', 0),
(140, 1, '2018-05-03 20:08:10', '2018-05-03 20:08:10', '', 'Student 10', '', 'publish', 'closed', 'closed', '', 'student-10', '', '', '2018-05-09 16:17:59', '2018-05-09 16:17:59', '', 0, 'http://2018.portshowl.io/?post_type=student&#038;p=140', 0, 'student', '', 0),
(141, 1, '2018-05-03 20:31:17', '2018-05-03 20:31:17', '', 'p_logo', '', 'inherit', 'open', 'closed', '', 'p_logo', '', '', '2018-05-03 20:31:17', '2018-05-03 20:31:17', '', 0, 'http://2018.portshowl.io/wp-content/uploads/2018/05/p_logo.png', 0, 'attachment', 'image/png', 0),
(142, 1, '2018-05-03 20:31:25', '2018-05-03 20:31:25', '', 'cropped-p_logo.png', '', 'inherit', 'open', 'closed', '', 'cropped-p_logo-png', '', '', '2018-05-03 20:31:25', '2018-05-03 20:31:25', '', 0, 'http://2018.portshowl.io/wp-content/uploads/2018/05/cropped-p_logo.png', 0, 'attachment', 'image/png', 0),
(143, 1, '2018-05-03 20:31:29', '2018-05-03 20:31:29', '{"portshowlio18::header_image":{"value":"http:\\/\\/2018.portshowl.io\\/wp-content\\/uploads\\/2018\\/05\\/cropped-p_logo.png","type":"theme_mod","user_id":1,"date_modified_gmt":"2018-05-03 20:31:29"},"portshowlio18::header_image_data":{"value":{"url":"http:\\/\\/2018.portshowl.io\\/wp-content\\/uploads\\/2018\\/05\\/cropped-p_logo.png","thumbnail_url":"http:\\/\\/2018.portshowl.io\\/wp-content\\/uploads\\/2018\\/05\\/cropped-p_logo.png","timestamp":1525379485942,"attachment_id":142,"width":1000,"height":1000},"type":"theme_mod","user_id":1,"date_modified_gmt":"2018-05-03 20:31:29"}}', '', '', 'trash', 'closed', 'closed', '', '2716ecc7-da92-4eab-9ebf-ba02ebbaff3b', '', '', '2018-05-03 20:31:29', '2018-05-03 20:31:29', '', 0, 'http://2018.portshowl.io/2018/05/03/2716ecc7-da92-4eab-9ebf-ba02ebbaff3b/', 0, 'customize_changeset', '', 0),
(144, 1, '2018-05-07 06:20:55', '2018-05-07 06:20:55', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'student hover photo', 'student_hover_photo', 'publish', 'closed', 'closed', '', 'field_5aeff0311f7c4', '', '', '2018-05-07 06:20:55', '2018-05-07 06:20:55', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&p=144', 1, 'acf-field', '', 0),
(145, 1, '2018-05-07 06:21:24', '2018-05-07 06:21:24', '', 'new', '', 'inherit', 'open', 'closed', '', 'new', '', '', '2018-05-07 06:54:46', '2018-05-07 06:54:46', '', 37, 'http://2018.portshowl.io/wp-content/uploads/2018/04/new.jpg', 0, 'attachment', 'image/jpeg', 0),
(146, 1, '2018-05-07 06:21:46', '2018-05-07 06:21:46', '', 'oso-perezoso', '', 'inherit', 'open', 'closed', '', 'oso-perezoso', '', '', '2018-05-07 06:54:30', '2018-05-07 06:54:30', '', 77, 'http://2018.portshowl.io/wp-content/uploads/2018/04/oso-perezoso.jpg', 0, 'attachment', 'image/jpeg', 0),
(147, 1, '2018-05-09 05:10:07', '2018-05-09 05:10:07', 'a:11:{s:4:"type";s:5:"radio";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:15:{s:7:"Default";s:7:"Default";s:11:"Advertising";s:11:"Advertising";s:13:"Art Direction";s:13:"Art Direction";s:8:"Branding";s:8:"Branding";s:12:"Illustration";s:12:"Illustration";s:11:"Game Design";s:11:"Game Design";s:6:"Layout";s:6:"Layout";s:15:"Motion Graphics";s:15:"Motion Graphics";s:9:"Packaging";s:9:"Packaging";s:12:"Print Design";s:12:"Print Design";s:10:"Typography";s:10:"Typography";s:7:"UX / UI";s:7:"UX / UI";s:10:"Web Design";s:10:"Web Design";s:15:"Virtual Reality";s:15:"Virtual Reality";s:13:"Visual Design";s:13:"Visual Design";}s:10:"allow_null";i:0;s:12:"other_choice";i:0;s:17:"save_other_choice";i:0;s:13:"default_value";s:0:"";s:6:"layout";s:8:"vertical";}', 'focus', 'focus', 'publish', 'closed', 'closed', '', 'field_5af2826546f6c', '', '', '2018-05-09 05:10:07', '2018-05-09 05:10:07', '', 38, 'http://2018.portshowl.io/?post_type=acf-field&p=147', 28, 'acf-field', '', 0),
(148, 1, '2018-05-10 17:20:48', '2018-05-10 17:20:48', '', 'Actual Home Page', '', 'publish', 'closed', 'closed', '', 'actual-home-page', '', '', '2018-05-10 17:20:48', '2018-05-10 17:20:48', '', 0, 'http://2018.portshowl.io/?page_id=148', 0, 'page', '', 0),
(149, 1, '2018-05-10 17:20:48', '2018-05-10 17:20:48', '', 'Actual Home Page', '', 'inherit', 'closed', 'closed', '', '148-revision-v1', '', '', '2018-05-10 17:20:48', '2018-05-10 17:20:48', '', 148, 'http://2018.portshowl.io/2018/05/10/148-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'Anna'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'theme_editor_notice'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:2:{s:64:"42174cd77ff664344ff017f95a4d532026e892e5196790b4d09b77becbbc81ed";a:4:{s:10:"expiration";i:1525846817;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36";s:5:"login";i:1525674017;}s:64:"5be9ae47417eb3151a2f6525b3907e720e0f88172997470338fc8d094c6a8e97";a:4:{s:10:"expiration";i:1526013348;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36";s:5:"login";i:1525840548;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '75'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:2:"::";}'),
(19, 1, 'wp_user-settings', 'editor=tinymce&libraryContent=browse'),
(20, 1, 'wp_user-settings-time', '1522952329'),
(21, 1, 'wp_yoast_notifications', 'a:5:{i:0;a:2:{s:7:"message";s:314:"The configuration wizard helps you to easily configure your site to have the optimal SEO settings.<br/>We have detected that you have not finished this wizard yet, so we recommend you to <a href="http://2018.portshowl.io/wp-admin/?page=wpseo_configurator">start the configuration wizard to configure Yoast SEO</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:31:"wpseo-dismiss-onboarding-notice";s:5:"nonce";N;s:8:"priority";d:0.8000000000000000444089209850062616169452667236328125;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:1;a:2:{s:7:"message";s:773:"We\'ve noticed you\'ve been using Yoast SEO for some time now; we hope you love it! We\'d be thrilled if you could <a href="https://yoa.st/rate-yoast-seo?utm_content=4.8">give us a 5 stars rating on WordPress.org</a>!\n\nIf you are experiencing issues, <a href="https://yoa.st/bugreport?utm_content=4.8">please file a bug report</a> and we\'ll do our best to help you out.\n\nBy the way, did you know we also have a <a href=\'https://yoa.st/premium-notification?utm_content=4.8\'>Premium plugin</a>? It offers advanced features, like a redirect manager and support for multiple keywords. It also comes with 24/7 personal support.\n\n<a class="button" href="http://2018.portshowl.io/wp-admin/?page=wpseo_dashboard&yoast_dismiss=upsell">Please don\'t show me this notification anymore</a>";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:19:"wpseo-upsell-notice";s:5:"nonce";N;s:8:"priority";d:0.8000000000000000444089209850062616169452667236328125;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:2;a:2:{s:7:"message";s:167:"Don\'t miss your crawl errors: <a href="http://2018.portshowl.io/wp-admin/admin.php?page=wpseo_search_console&tab=settings">connect with Google Search Console here</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:3;a:2:{s:7:"message";s:258:"You still have the default WordPress tagline, even an empty one is probably better. <a href="http://2018.portshowl.io/wp-admin/customize.php?url=http%3A%2F%2Flocalhost%2Fwp-admin%2Ftools.php%3Fpage%3Dwp-migrate-db-pro">You can fix this in the customizer</a>.";s:7:"options";a:8:{s:4:"type";s:5:"error";s:2:"id";s:28:"wpseo-dismiss-tagline-notice";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:4;a:2:{s:7:"message";s:221:"<strong>Huge SEO Issue: You\'re blocking access to robots.</strong> You must <a href="http://2018.portshowl.io/wp-admin/options-reading.php">go to your Reading Settings</a> and uncheck the box for Search Engine Visibility.";s:7:"options";a:8:{s:4:"type";s:5:"error";s:2:"id";s:32:"wpseo-dismiss-blog-public-notice";s:5:"nonce";N;s:8:"priority";i:1;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}}'),
(22, 1, '_yoast_wpseo_profile_updated', '1524764891'),
(23, 1, 'wp_media_library_mode', 'grid'),
(24, 1, 'meta-box-order_acf-field-group', 'a:3:{s:4:"side";s:9:"submitdiv";s:6:"normal";s:80:"acf-field-group-fields,acf-field-group-locations,acf-field-group-options,slugdiv";s:8:"advanced";s:0:"";}'),
(25, 1, 'screen_layout_acf-field-group', '1'),
(26, 1, 'closedpostboxes_dashboard', 'a:0:{}'),
(27, 1, 'metaboxhidden_dashboard', 'a:1:{i:0;s:17:"dashboard_primary";}'),
(28, 1, 'closedpostboxes_acf-field-group', 'a:0:{}'),
(29, 1, 'metaboxhidden_acf-field-group', 'a:1:{i:0;s:7:"slugdiv";}'),
(30, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(31, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:21:"add-post-type-student";i:1;s:12:"add-post_tag";i:2;s:11:"add-student";}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'Anna', '$P$B58aPdYPqR0tge6awN3n7JUW0szcFd/', 'anna', 'atiagina@gmail.com', '', '2018-04-05 02:11:06', '', 0, 'Anna') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_wppusher_packages`
#

DROP TABLE IF EXISTS `wp_wppusher_packages`;


#
# Table structure of table `wp_wppusher_packages`
#

CREATE TABLE `wp_wppusher_packages` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `package` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `repository` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `branch` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'master',
  `type` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `ptd` int(11) NOT NULL,
  `host` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `private` int(11) NOT NULL,
  `subdirectory` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wppusher_packages`
#

#
# End of data contents of table `wp_wppusher_packages`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

